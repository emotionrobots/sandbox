﻿Public Enum PwmStatusEnum
    Forward
    Off
    Reverse
End Enum
