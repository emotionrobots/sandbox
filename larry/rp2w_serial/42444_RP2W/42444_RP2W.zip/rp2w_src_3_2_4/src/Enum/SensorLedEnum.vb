﻿Public Enum SensorLedEnum
    Deactivated
    Red
    Yellow
    Green
End Enum
