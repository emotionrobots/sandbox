﻿Public Enum MotorIdEnum
    Right
    Left
End Enum
