﻿Public Enum DigitalInputsFlagsEnum
    InputBit0 = 1
    InputBit1 = 2
    InputBit2 = 4
    InputBit3 = 8
    InputBit4 = 16
    InputBit5 = 32
    InputBit6 = 64
    InputBit7 = 128
End Enum
