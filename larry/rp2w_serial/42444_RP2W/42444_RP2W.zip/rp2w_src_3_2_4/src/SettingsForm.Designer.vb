<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SettingsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SettingsForm))
        Me.CameraPanGroupBox = New System.Windows.Forms.GroupBox
        Me.panStepTextBox = New System.Windows.Forms.TextBox
        Me.minPanPositionTextBox = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.maxPanPositionTextBox = New System.Windows.Forms.TextBox
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.reversePanPosition1TextBox = New System.Windows.Forms.TextBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.reversePanPosition2TextBox = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.rightPanPositionTextBox = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.forwardPanPositionTextBox = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.leftPanPositionTextBox = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.CameraTiltGroupBox = New System.Windows.Forms.GroupBox
        Me.tiltStepTextBox = New System.Windows.Forms.TextBox
        Me.minTiltPositionTextBox = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.maxTiltPositionTextBox = New System.Windows.Forms.TextBox
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.downPositionTextBox = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.horizontalPositionTextBox = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.upPositionTextBox = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.TimersGroupBox = New System.Windows.Forms.GroupBox
        Me.chbEnableTiltTimerReset = New System.Windows.Forms.CheckBox
        Me.chbEnablePanTimerReset = New System.Windows.Forms.CheckBox
        Me.TextBoxMaximalNetTimeout2 = New System.Windows.Forms.TextBox
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.TextBoxMaximalNetLatency = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.LabelMaximalNetLatency = New System.Windows.Forms.Label
        Me.tiltTimerIntervalTextBox = New System.Windows.Forms.TextBox
        Me.Label33 = New System.Windows.Forms.Label
        Me.panTimerIntervalTextBox = New System.Windows.Forms.TextBox
        Me.Label34 = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.txTimerIntervalTextBox = New System.Windows.Forms.TextBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.updateAndCloseButton = New System.Windows.Forms.Button
        Me.cancelFormButton = New System.Windows.Forms.Button
        Me.CommunicationGroupBox = New System.Windows.Forms.GroupBox
        Me.dataCOMComboBox = New System.Windows.Forms.ComboBox
        Me.dataAutoCheckBox = New System.Windows.Forms.CheckBox
        Me.dataLabel = New System.Windows.Forms.Label
        Me.EncoderCalibrationGroupBox = New System.Windows.Forms.GroupBox
        Me.RadioButtonEncoderUnitMetric = New System.Windows.Forms.RadioButton
        Me.RadioButtonEncoderUnitImperial = New System.Windows.Forms.RadioButton
        Me.LabelEncoderUnits = New System.Windows.Forms.Label
        Me.LeftEncoderCalibrationTextBox = New System.Windows.Forms.TextBox
        Me.lecCountInchLabel = New System.Windows.Forms.Label
        Me.LeftEncoderCalibrationLabel = New System.Windows.Forms.Label
        Me.RightEncoderCalibrationTextBox = New System.Windows.Forms.TextBox
        Me.recCountInchLabel = New System.Windows.Forms.Label
        Me.RightEncoderCalibrationLabel = New System.Windows.Forms.Label
        Me.OutputsGroupBox = New System.Windows.Forms.GroupBox
        Me.Output4CheckBox = New System.Windows.Forms.CheckBox
        Me.Output3CheckBox = New System.Windows.Forms.CheckBox
        Me.Output2CheckBox = New System.Windows.Forms.CheckBox
        Me.Output1CheckBox = New System.Windows.Forms.CheckBox
        Me.Output4TextBox = New System.Windows.Forms.TextBox
        Me.Output3TextBox = New System.Windows.Forms.TextBox
        Me.Output2TextBox = New System.Windows.Forms.TextBox
        Me.Output1TextBox = New System.Windows.Forms.TextBox
        Me.Output4Label = New System.Windows.Forms.Label
        Me.Output3Label = New System.Windows.Forms.Label
        Me.Output2Label = New System.Windows.Forms.Label
        Me.Output1Label = New System.Windows.Forms.Label
        Me.AnalogInputsGroupBox = New System.Windows.Forms.GroupBox
        Me.AnalogInput3ScaleTextBox = New System.Windows.Forms.TextBox
        Me.AnalogInput3ScaleLabel = New System.Windows.Forms.Label
        Me.AnalogInput2ScaleTextBox = New System.Windows.Forms.TextBox
        Me.AnalogInput2ScaleLabel = New System.Windows.Forms.Label
        Me.AnalogInput1ScaleTextBox = New System.Windows.Forms.TextBox
        Me.AnalogInput1ScaleLabel = New System.Windows.Forms.Label
        Me.AnalogInput3UnitTextBox = New System.Windows.Forms.TextBox
        Me.AnalogInput2UnitTextBox = New System.Windows.Forms.TextBox
        Me.AnalogInput1UnitTextBox = New System.Windows.Forms.TextBox
        Me.AnalogInput3CheckBox = New System.Windows.Forms.CheckBox
        Me.AnalogInput2CheckBox = New System.Windows.Forms.CheckBox
        Me.AnalogInput1CheckBox = New System.Windows.Forms.CheckBox
        Me.AnalogInput3TextBox = New System.Windows.Forms.TextBox
        Me.AnalogInput2TextBox = New System.Windows.Forms.TextBox
        Me.AnalogInput1TextBox = New System.Windows.Forms.TextBox
        Me.AnalogInput3Label = New System.Windows.Forms.Label
        Me.AnalogInput2Label = New System.Windows.Forms.Label
        Me.AnalogInput1Label = New System.Windows.Forms.Label
        Me.DigitalInputsGroupBox = New System.Windows.Forms.GroupBox
        Me.DigitalInput4CheckBox = New System.Windows.Forms.CheckBox
        Me.DigitalInput3CheckBox = New System.Windows.Forms.CheckBox
        Me.DigitalInput2CheckBox = New System.Windows.Forms.CheckBox
        Me.DigitalInput1CheckBox = New System.Windows.Forms.CheckBox
        Me.DigitalInput4TextBox = New System.Windows.Forms.TextBox
        Me.DigitalInput3TextBox = New System.Windows.Forms.TextBox
        Me.DigitalInput2TextBox = New System.Windows.Forms.TextBox
        Me.DigitalInput1TextBox = New System.Windows.Forms.TextBox
        Me.DigitalInput4Label = New System.Windows.Forms.Label
        Me.DigitalInput3Label = New System.Windows.Forms.Label
        Me.DigitalInput2Label = New System.Windows.Forms.Label
        Me.DigitalInput1Label = New System.Windows.Forms.Label
        Me.SettingsToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.AnalogInput3WarningsCheckBox = New System.Windows.Forms.CheckBox
        Me.AnalogInput2WarningsCheckBox = New System.Windows.Forms.CheckBox
        Me.AnalogInput1WarningsCheckBox = New System.Windows.Forms.CheckBox
        Me.AllowedRange3LowTextBox = New System.Windows.Forms.TextBox
        Me.AllowedRange2LowTextBox = New System.Windows.Forms.TextBox
        Me.AllowedRange1LowTextBox = New System.Windows.Forms.TextBox
        Me.CameraIPAddressTextBox = New System.Windows.Forms.TextBox
        Me.CameraPortTextBox = New System.Windows.Forms.TextBox
        Me.CameraLoginTextBox = New System.Windows.Forms.TextBox
        Me.CameraPasswordTextBox = New System.Windows.Forms.TextBox
        Me.cmbVideoEncodingResolution = New System.Windows.Forms.ComboBox
        Me.txtVideoFrameCaptureInterval = New System.Windows.Forms.TextBox
        Me.cmbVideoH264SpeedLevel = New System.Windows.Forms.ComboBox
        Me.cmbVideoH264Profile = New System.Windows.Forms.ComboBox
        Me.txtVideoFrameRate = New System.Windows.Forms.TextBox
        Me.txtVideoIFrameFrequency = New System.Windows.Forms.TextBox
        Me.txtVideoBitRate = New System.Windows.Forms.TextBox
        Me.OutOfRangeWarningsGroupBox = New System.Windows.Forms.GroupBox
        Me.AllowedRange3HighTextBox = New System.Windows.Forms.TextBox
        Me.AnalogInput3WarningsHighLabel = New System.Windows.Forms.Label
        Me.AllowedRange2HighTextBox = New System.Windows.Forms.TextBox
        Me.AnalogInput2WarningsHighLabel = New System.Windows.Forms.Label
        Me.AllowedRange1HighTextBox = New System.Windows.Forms.TextBox
        Me.AnalogInput1WarningsHighLabel = New System.Windows.Forms.Label
        Me.AnalogInput3WarningsLowLabel = New System.Windows.Forms.Label
        Me.AnalogInput2WarningsLowLabel = New System.Windows.Forms.Label
        Me.AnalogInput1WarningsLowLabel = New System.Windows.Forms.Label
        Me.SettingsTabControl = New System.Windows.Forms.TabControl
        Me.CameraPanAndTiltTabPage = New System.Windows.Forms.TabPage
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.CheckBoxInvertTilt = New System.Windows.Forms.CheckBox
        Me.CheckBoxInvertPan = New System.Windows.Forms.CheckBox
        Me.InputsOutputsTabPage = New System.Windows.Forms.TabPage
        Me.Label19 = New System.Windows.Forms.Label
        Me.GroupBoxUltrasonicSensor = New System.Windows.Forms.GroupBox
        Me.RadioButtonSensorUnitMetric = New System.Windows.Forms.RadioButton
        Me.RadioButtonSensorUnitImperial = New System.Windows.Forms.RadioButton
        Me.LabelUltrasonicUnits = New System.Windows.Forms.Label
        Me.TextBoxOffset = New System.Windows.Forms.TextBox
        Me.LabelOffset = New System.Windows.Forms.Label
        Me.TextBoxMultiplier = New System.Windows.Forms.TextBox
        Me.LabelUSSMultiplier = New System.Windows.Forms.Label
        Me.MotorTabPage = New System.Windows.Forms.TabPage
        Me.DriveControlSettingsGroupBox = New System.Windows.Forms.GroupBox
        Me.chbDisableMotorMixing = New System.Windows.Forms.CheckBox
        Me.UseReverseBitCheckBox = New System.Windows.Forms.CheckBox
        Me.MotorOffTextBox = New System.Windows.Forms.TextBox
        Me.MotorOffLabel = New System.Windows.Forms.Label
        Me.MotorReverseFastLabel = New System.Windows.Forms.Label
        Me.MotorReverseFastTextBox = New System.Windows.Forms.TextBox
        Me.MotorReverseSlowTextBox = New System.Windows.Forms.TextBox
        Me.MotoroForwardFastTextBox = New System.Windows.Forms.TextBox
        Me.MotorForwardFastLabel = New System.Windows.Forms.Label
        Me.MotorForwardSlowTextBox = New System.Windows.Forms.TextBox
        Me.MotorReverseSlowLabel = New System.Windows.Forms.Label
        Me.MotorForwardSlowLabel = New System.Windows.Forms.Label
        Me.CameraPresetTabPage = New System.Windows.Forms.TabPage
        Me.grbPreset4 = New System.Windows.Forms.GroupBox
        Me.Label51 = New System.Windows.Forms.Label
        Me.Label52 = New System.Windows.Forms.Label
        Me.txtCameraPreset4Tilt = New System.Windows.Forms.TextBox
        Me.txtCameraPreset4Pan = New System.Windows.Forms.TextBox
        Me.Label53 = New System.Windows.Forms.Label
        Me.Label54 = New System.Windows.Forms.Label
        Me.grbPreset3 = New System.Windows.Forms.GroupBox
        Me.Label47 = New System.Windows.Forms.Label
        Me.Label48 = New System.Windows.Forms.Label
        Me.txtCameraPreset3Tilt = New System.Windows.Forms.TextBox
        Me.txtCameraPreset3Pan = New System.Windows.Forms.TextBox
        Me.Label49 = New System.Windows.Forms.Label
        Me.Label50 = New System.Windows.Forms.Label
        Me.grbPreset2 = New System.Windows.Forms.GroupBox
        Me.Label43 = New System.Windows.Forms.Label
        Me.Label44 = New System.Windows.Forms.Label
        Me.txtCameraPreset2Tilt = New System.Windows.Forms.TextBox
        Me.txtCameraPreset2Pan = New System.Windows.Forms.TextBox
        Me.Label45 = New System.Windows.Forms.Label
        Me.Label46 = New System.Windows.Forms.Label
        Me.grbPreset1 = New System.Windows.Forms.GroupBox
        Me.Label42 = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.txtCameraPreset1Tilt = New System.Windows.Forms.TextBox
        Me.txtCameraPreset1Pan = New System.Windows.Forms.TextBox
        Me.Label40 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.tbtPresetInfo = New System.Windows.Forms.Label
        Me.CommunicationTabPage = New System.Windows.Forms.TabPage
        Me.CameraDeviceGroupBox = New System.Windows.Forms.GroupBox
        Me.RadioButtonRunAsClient = New System.Windows.Forms.RadioButton
        Me.RadioButtonRunAsServer = New System.Windows.Forms.RadioButton
        Me.CameraConnectionGroupBox = New System.Windows.Forms.GroupBox
        Me.cbEnableRemoteControllingAfterStartup = New System.Windows.Forms.CheckBox
        Me.CameraPasswordLabel = New System.Windows.Forms.Label
        Me.CameraLoginLabel = New System.Windows.Forms.Label
        Me.CameraPortLabel = New System.Windows.Forms.Label
        Me.CameraIPLabel = New System.Windows.Forms.Label
        Me.ComunicationCametaTabPage = New System.Windows.Forms.TabPage
        Me.AudioGroupBox = New System.Windows.Forms.GroupBox
        Me.cmbAudioOutput = New System.Windows.Forms.ComboBox
        Me.lblAudioOutput = New System.Windows.Forms.Label
        Me.cmbAudioInput = New System.Windows.Forms.ComboBox
        Me.lblAudioInput = New System.Windows.Forms.Label
        Me.UsbCameraEncodingGroupBox = New System.Windows.Forms.GroupBox
        Me.lblCodecInfo = New System.Windows.Forms.Label
        Me.lblVideoH264Profile = New System.Windows.Forms.Label
        Me.lblVideoH264SpeedLevel = New System.Windows.Forms.Label
        Me.lblVideoFrameRate = New System.Windows.Forms.Label
        Me.lblVideoFrameCaptureInterval = New System.Windows.Forms.Label
        Me.lblVideoBitRate = New System.Windows.Forms.Label
        Me.lblIFrameFrequency = New System.Windows.Forms.Label
        Me.lblVideoEncodingResolution = New System.Windows.Forms.Label
        Me.UsbCameraConnectionGroupBox = New System.Windows.Forms.GroupBox
        Me.cmbVideoPreviewSize = New System.Windows.Forms.ComboBox
        Me.lblVideoPreviewSize = New System.Windows.Forms.Label
        Me.UsbCamVideoDeviceComboBox = New System.Windows.Forms.ComboBox
        Me.UsbCamVideoDeviceLabel = New System.Windows.Forms.Label
        Me.FunctionsTabPage = New System.Windows.Forms.TabPage
        Me.chbDisableZoom = New System.Windows.Forms.CheckBox
        Me.chbDisablePanTilt = New System.Windows.Forms.CheckBox
        Me.chbDisableBumperSwitch = New System.Windows.Forms.CheckBox
        Me.chbDisableSonar = New System.Windows.Forms.CheckBox
        Me.chbDisableEncoders = New System.Windows.Forms.CheckBox
        Me.chbDisableEncodersCount = New System.Windows.Forms.CheckBox
        Me.CameraPanGroupBox.SuspendLayout()
        Me.CameraTiltGroupBox.SuspendLayout()
        Me.TimersGroupBox.SuspendLayout()
        Me.CommunicationGroupBox.SuspendLayout()
        Me.EncoderCalibrationGroupBox.SuspendLayout()
        Me.OutputsGroupBox.SuspendLayout()
        Me.AnalogInputsGroupBox.SuspendLayout()
        Me.DigitalInputsGroupBox.SuspendLayout()
        Me.OutOfRangeWarningsGroupBox.SuspendLayout()
        Me.SettingsTabControl.SuspendLayout()
        Me.CameraPanAndTiltTabPage.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.InputsOutputsTabPage.SuspendLayout()
        Me.GroupBoxUltrasonicSensor.SuspendLayout()
        Me.MotorTabPage.SuspendLayout()
        Me.DriveControlSettingsGroupBox.SuspendLayout()
        Me.CameraPresetTabPage.SuspendLayout()
        Me.grbPreset4.SuspendLayout()
        Me.grbPreset3.SuspendLayout()
        Me.grbPreset2.SuspendLayout()
        Me.grbPreset1.SuspendLayout()
        Me.CommunicationTabPage.SuspendLayout()
        Me.CameraDeviceGroupBox.SuspendLayout()
        Me.CameraConnectionGroupBox.SuspendLayout()
        Me.ComunicationCametaTabPage.SuspendLayout()
        Me.AudioGroupBox.SuspendLayout()
        Me.UsbCameraEncodingGroupBox.SuspendLayout()
        Me.UsbCameraConnectionGroupBox.SuspendLayout()
        Me.FunctionsTabPage.SuspendLayout()
        Me.SuspendLayout()
        '
        'CameraPanGroupBox
        '
        Me.CameraPanGroupBox.Controls.Add(Me.panStepTextBox)
        Me.CameraPanGroupBox.Controls.Add(Me.minPanPositionTextBox)
        Me.CameraPanGroupBox.Controls.Add(Me.Label27)
        Me.CameraPanGroupBox.Controls.Add(Me.Label28)
        Me.CameraPanGroupBox.Controls.Add(Me.maxPanPositionTextBox)
        Me.CameraPanGroupBox.Controls.Add(Me.Label25)
        Me.CameraPanGroupBox.Controls.Add(Me.Label26)
        Me.CameraPanGroupBox.Controls.Add(Me.reversePanPosition1TextBox)
        Me.CameraPanGroupBox.Controls.Add(Me.Label23)
        Me.CameraPanGroupBox.Controls.Add(Me.Label24)
        Me.CameraPanGroupBox.Controls.Add(Me.Label7)
        Me.CameraPanGroupBox.Controls.Add(Me.Label8)
        Me.CameraPanGroupBox.Controls.Add(Me.reversePanPosition2TextBox)
        Me.CameraPanGroupBox.Controls.Add(Me.Label9)
        Me.CameraPanGroupBox.Controls.Add(Me.Label10)
        Me.CameraPanGroupBox.Controls.Add(Me.rightPanPositionTextBox)
        Me.CameraPanGroupBox.Controls.Add(Me.Label11)
        Me.CameraPanGroupBox.Controls.Add(Me.Label12)
        Me.CameraPanGroupBox.Controls.Add(Me.forwardPanPositionTextBox)
        Me.CameraPanGroupBox.Controls.Add(Me.Label5)
        Me.CameraPanGroupBox.Controls.Add(Me.Label6)
        Me.CameraPanGroupBox.Controls.Add(Me.leftPanPositionTextBox)
        Me.CameraPanGroupBox.Controls.Add(Me.Label3)
        Me.CameraPanGroupBox.Controls.Add(Me.Label4)
        Me.CameraPanGroupBox.Location = New System.Drawing.Point(8, 6)
        Me.CameraPanGroupBox.Name = "CameraPanGroupBox"
        Me.CameraPanGroupBox.Size = New System.Drawing.Size(300, 221)
        Me.CameraPanGroupBox.TabIndex = 0
        Me.CameraPanGroupBox.TabStop = False
        Me.CameraPanGroupBox.Text = "Camera Pan Settings"
        '
        'panStepTextBox
        '
        Me.panStepTextBox.Location = New System.Drawing.Point(125, 192)
        Me.panStepTextBox.Name = "panStepTextBox"
        Me.panStepTextBox.Size = New System.Drawing.Size(100, 20)
        Me.panStepTextBox.TabIndex = 25
        Me.panStepTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.panStepTextBox, "Step size for DPad key press")
        '
        'minPanPositionTextBox
        '
        Me.minPanPositionTextBox.Location = New System.Drawing.Point(125, 167)
        Me.minPanPositionTextBox.Name = "minPanPositionTextBox"
        Me.minPanPositionTextBox.Size = New System.Drawing.Size(100, 20)
        Me.minPanPositionTextBox.TabIndex = 22
        Me.minPanPositionTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.minPanPositionTextBox, "Minimum Servo Postion Value")
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(231, 170)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(59, 13)
        Me.Label27.TabIndex = 24
        Me.Label27.Text = "Increments"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(30, 170)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(89, 13)
        Me.Label28.TabIndex = 23
        Me.Label28.Text = "Min Pan Position:"
        '
        'maxPanPositionTextBox
        '
        Me.maxPanPositionTextBox.Location = New System.Drawing.Point(125, 142)
        Me.maxPanPositionTextBox.Name = "maxPanPositionTextBox"
        Me.maxPanPositionTextBox.Size = New System.Drawing.Size(100, 20)
        Me.maxPanPositionTextBox.TabIndex = 19
        Me.maxPanPositionTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.maxPanPositionTextBox, "Maximum Servo Postion Value")
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(231, 145)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(59, 13)
        Me.Label25.TabIndex = 21
        Me.Label25.Text = "Increments"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(27, 145)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(92, 13)
        Me.Label26.TabIndex = 20
        Me.Label26.Text = "Max Pan Position:"
        '
        'reversePanPosition1TextBox
        '
        Me.reversePanPosition1TextBox.Location = New System.Drawing.Point(125, 17)
        Me.reversePanPosition1TextBox.Name = "reversePanPosition1TextBox"
        Me.reversePanPosition1TextBox.Size = New System.Drawing.Size(100, 20)
        Me.reversePanPosition1TextBox.TabIndex = 0
        Me.reversePanPosition1TextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.reversePanPosition1TextBox, "Desired Set Point Position")
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(231, 20)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(59, 13)
        Me.Label23.TabIndex = 18
        Me.Label23.Text = "Increments"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(7, 20)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(112, 13)
        Me.Label24.TabIndex = 17
        Me.Label24.Text = "Reverse Pan Position:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(231, 195)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(59, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Increments"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 195)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(107, 13)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "DPad Pan Step Size:"
        '
        'reversePanPosition2TextBox
        '
        Me.reversePanPosition2TextBox.Location = New System.Drawing.Point(125, 117)
        Me.reversePanPosition2TextBox.Name = "reversePanPosition2TextBox"
        Me.reversePanPosition2TextBox.Size = New System.Drawing.Size(100, 20)
        Me.reversePanPosition2TextBox.TabIndex = 4
        Me.reversePanPosition2TextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.reversePanPosition2TextBox, "Desired Set Point Position")
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(231, 120)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(59, 13)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Increments"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(7, 120)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(112, 13)
        Me.Label10.TabIndex = 11
        Me.Label10.Text = "Reverse Pan Position:"
        '
        'rightPanPositionTextBox
        '
        Me.rightPanPositionTextBox.Location = New System.Drawing.Point(125, 92)
        Me.rightPanPositionTextBox.Name = "rightPanPositionTextBox"
        Me.rightPanPositionTextBox.Size = New System.Drawing.Size(100, 20)
        Me.rightPanPositionTextBox.TabIndex = 3
        Me.rightPanPositionTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.rightPanPositionTextBox, "Desired Set Point Position")
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(231, 95)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(59, 13)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "Increments"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(22, 95)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(97, 13)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "Right Pan Position:"
        '
        'forwardPanPositionTextBox
        '
        Me.forwardPanPositionTextBox.Location = New System.Drawing.Point(125, 67)
        Me.forwardPanPositionTextBox.Name = "forwardPanPositionTextBox"
        Me.forwardPanPositionTextBox.Size = New System.Drawing.Size(100, 20)
        Me.forwardPanPositionTextBox.TabIndex = 2
        Me.forwardPanPositionTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.forwardPanPositionTextBox, "Desired Set Point Position")
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(231, 70)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(59, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Increments"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(9, 70)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(110, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Forward Pan Position:"
        '
        'leftPanPositionTextBox
        '
        Me.leftPanPositionTextBox.Location = New System.Drawing.Point(125, 42)
        Me.leftPanPositionTextBox.Name = "leftPanPositionTextBox"
        Me.leftPanPositionTextBox.Size = New System.Drawing.Size(100, 20)
        Me.leftPanPositionTextBox.TabIndex = 1
        Me.leftPanPositionTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.leftPanPositionTextBox, "Desired Set Point Position")
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(231, 45)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(59, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Increments"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(29, 45)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(90, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Left Pan Position:"
        '
        'CameraTiltGroupBox
        '
        Me.CameraTiltGroupBox.Controls.Add(Me.tiltStepTextBox)
        Me.CameraTiltGroupBox.Controls.Add(Me.minTiltPositionTextBox)
        Me.CameraTiltGroupBox.Controls.Add(Me.Label17)
        Me.CameraTiltGroupBox.Controls.Add(Me.Label18)
        Me.CameraTiltGroupBox.Controls.Add(Me.maxTiltPositionTextBox)
        Me.CameraTiltGroupBox.Controls.Add(Me.Label29)
        Me.CameraTiltGroupBox.Controls.Add(Me.Label30)
        Me.CameraTiltGroupBox.Controls.Add(Me.Label31)
        Me.CameraTiltGroupBox.Controls.Add(Me.Label32)
        Me.CameraTiltGroupBox.Controls.Add(Me.downPositionTextBox)
        Me.CameraTiltGroupBox.Controls.Add(Me.Label15)
        Me.CameraTiltGroupBox.Controls.Add(Me.Label16)
        Me.CameraTiltGroupBox.Controls.Add(Me.horizontalPositionTextBox)
        Me.CameraTiltGroupBox.Controls.Add(Me.Label13)
        Me.CameraTiltGroupBox.Controls.Add(Me.Label14)
        Me.CameraTiltGroupBox.Controls.Add(Me.upPositionTextBox)
        Me.CameraTiltGroupBox.Controls.Add(Me.Label1)
        Me.CameraTiltGroupBox.Controls.Add(Me.Label2)
        Me.CameraTiltGroupBox.Location = New System.Drawing.Point(314, 6)
        Me.CameraTiltGroupBox.Name = "CameraTiltGroupBox"
        Me.CameraTiltGroupBox.Size = New System.Drawing.Size(302, 175)
        Me.CameraTiltGroupBox.TabIndex = 1
        Me.CameraTiltGroupBox.TabStop = False
        Me.CameraTiltGroupBox.Text = "Camera Tilt Settings"
        '
        'tiltStepTextBox
        '
        Me.tiltStepTextBox.Location = New System.Drawing.Point(125, 144)
        Me.tiltStepTextBox.Name = "tiltStepTextBox"
        Me.tiltStepTextBox.Size = New System.Drawing.Size(100, 20)
        Me.tiltStepTextBox.TabIndex = 34
        Me.tiltStepTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.tiltStepTextBox, "Step size for DPad key press")
        '
        'minTiltPositionTextBox
        '
        Me.minTiltPositionTextBox.Location = New System.Drawing.Point(125, 119)
        Me.minTiltPositionTextBox.Name = "minTiltPositionTextBox"
        Me.minTiltPositionTextBox.Size = New System.Drawing.Size(100, 20)
        Me.minTiltPositionTextBox.TabIndex = 31
        Me.minTiltPositionTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.minTiltPositionTextBox, "Minimum Servo Postion Value")
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(231, 122)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(59, 13)
        Me.Label17.TabIndex = 33
        Me.Label17.Text = "Increments"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(35, 122)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(84, 13)
        Me.Label18.TabIndex = 32
        Me.Label18.Text = "Min Tilt Position:"
        '
        'maxTiltPositionTextBox
        '
        Me.maxTiltPositionTextBox.Location = New System.Drawing.Point(125, 94)
        Me.maxTiltPositionTextBox.Name = "maxTiltPositionTextBox"
        Me.maxTiltPositionTextBox.Size = New System.Drawing.Size(100, 20)
        Me.maxTiltPositionTextBox.TabIndex = 28
        Me.maxTiltPositionTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.maxTiltPositionTextBox, "Maximum Servo Postion Value")
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(231, 97)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(59, 13)
        Me.Label29.TabIndex = 30
        Me.Label29.Text = "Increments"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(32, 97)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(87, 13)
        Me.Label30.TabIndex = 29
        Me.Label30.Text = "Max Tilt Position:"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(231, 147)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(59, 13)
        Me.Label31.TabIndex = 27
        Me.Label31.Text = "Increments"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(17, 147)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(102, 13)
        Me.Label32.TabIndex = 26
        Me.Label32.Text = "DPad Tilt Step Size:"
        '
        'downPositionTextBox
        '
        Me.downPositionTextBox.Location = New System.Drawing.Point(125, 68)
        Me.downPositionTextBox.Name = "downPositionTextBox"
        Me.downPositionTextBox.Size = New System.Drawing.Size(100, 20)
        Me.downPositionTextBox.TabIndex = 8
        Me.downPositionTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.downPositionTextBox, "Desired Set Point Position")
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(231, 71)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(59, 13)
        Me.Label15.TabIndex = 12
        Me.Label15.Text = "Increments"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(41, 71)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(78, 13)
        Me.Label16.TabIndex = 11
        Me.Label16.Text = "Down Position:"
        '
        'horizontalPositionTextBox
        '
        Me.horizontalPositionTextBox.Location = New System.Drawing.Point(125, 43)
        Me.horizontalPositionTextBox.Name = "horizontalPositionTextBox"
        Me.horizontalPositionTextBox.Size = New System.Drawing.Size(100, 20)
        Me.horizontalPositionTextBox.TabIndex = 7
        Me.horizontalPositionTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.horizontalPositionTextBox, "Desired Set Point Position")
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(231, 46)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(59, 13)
        Me.Label13.TabIndex = 9
        Me.Label13.Text = "Increments"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(22, 46)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(97, 13)
        Me.Label14.TabIndex = 8
        Me.Label14.Text = "Horizontal Position:"
        '
        'upPositionTextBox
        '
        Me.upPositionTextBox.Location = New System.Drawing.Point(125, 18)
        Me.upPositionTextBox.Name = "upPositionTextBox"
        Me.upPositionTextBox.Size = New System.Drawing.Size(100, 20)
        Me.upPositionTextBox.TabIndex = 6
        Me.upPositionTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.upPositionTextBox, "Desired Set Point Position")
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(231, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Increments"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(55, 21)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Up Position:"
        '
        'TimersGroupBox
        '
        Me.TimersGroupBox.Controls.Add(Me.chbEnableTiltTimerReset)
        Me.TimersGroupBox.Controls.Add(Me.chbEnablePanTimerReset)
        Me.TimersGroupBox.Controls.Add(Me.TextBoxMaximalNetTimeout2)
        Me.TimersGroupBox.Controls.Add(Me.Label37)
        Me.TimersGroupBox.Controls.Add(Me.Label38)
        Me.TimersGroupBox.Controls.Add(Me.TextBoxMaximalNetLatency)
        Me.TimersGroupBox.Controls.Add(Me.Label20)
        Me.TimersGroupBox.Controls.Add(Me.LabelMaximalNetLatency)
        Me.TimersGroupBox.Controls.Add(Me.tiltTimerIntervalTextBox)
        Me.TimersGroupBox.Controls.Add(Me.Label33)
        Me.TimersGroupBox.Controls.Add(Me.panTimerIntervalTextBox)
        Me.TimersGroupBox.Controls.Add(Me.Label34)
        Me.TimersGroupBox.Controls.Add(Me.Label35)
        Me.TimersGroupBox.Controls.Add(Me.Label36)
        Me.TimersGroupBox.Controls.Add(Me.txTimerIntervalTextBox)
        Me.TimersGroupBox.Controls.Add(Me.Label21)
        Me.TimersGroupBox.Controls.Add(Me.Label22)
        Me.TimersGroupBox.Location = New System.Drawing.Point(8, 6)
        Me.TimersGroupBox.Name = "TimersGroupBox"
        Me.TimersGroupBox.Size = New System.Drawing.Size(302, 141)
        Me.TimersGroupBox.TabIndex = 2
        Me.TimersGroupBox.TabStop = False
        Me.TimersGroupBox.Text = "Timer Settings"
        '
        'chbEnableTiltTimerReset
        '
        Me.chbEnableTiltTimerReset.AutoSize = True
        Me.chbEnableTiltTimerReset.Location = New System.Drawing.Point(210, 69)
        Me.chbEnableTiltTimerReset.Name = "chbEnableTiltTimerReset"
        Me.chbEnableTiltTimerReset.Size = New System.Drawing.Size(15, 14)
        Me.chbEnableTiltTimerReset.TabIndex = 26
        Me.chbEnableTiltTimerReset.UseVisualStyleBackColor = True
        '
        'chbEnablePanTimerReset
        '
        Me.chbEnablePanTimerReset.AutoSize = True
        Me.chbEnablePanTimerReset.Location = New System.Drawing.Point(210, 42)
        Me.chbEnablePanTimerReset.Name = "chbEnablePanTimerReset"
        Me.chbEnablePanTimerReset.Size = New System.Drawing.Size(15, 14)
        Me.chbEnablePanTimerReset.TabIndex = 25
        Me.chbEnablePanTimerReset.UseVisualStyleBackColor = True
        '
        'TextBoxMaximalNetTimeout2
        '
        Me.TextBoxMaximalNetTimeout2.Location = New System.Drawing.Point(125, 113)
        Me.TextBoxMaximalNetTimeout2.Name = "TextBoxMaximalNetTimeout2"
        Me.TextBoxMaximalNetTimeout2.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxMaximalNetTimeout2.TabIndex = 23
        Me.TextBoxMaximalNetTimeout2.Text = "2000"
        Me.SettingsToolTip.SetToolTip(Me.TextBoxMaximalNetTimeout2, "Auto Power Delay for Output 2")
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(231, 116)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(32, 13)
        Me.Label37.TabIndex = 24
        Me.Label37.Text = "msec"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(10, 116)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(109, 13)
        Me.Label38.TabIndex = 22
        Me.Label38.Text = "Program stop timeout:"
        '
        'TextBoxMaximalNetLatency
        '
        Me.TextBoxMaximalNetLatency.Location = New System.Drawing.Point(125, 89)
        Me.TextBoxMaximalNetLatency.Name = "TextBoxMaximalNetLatency"
        Me.TextBoxMaximalNetLatency.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxMaximalNetLatency.TabIndex = 20
        Me.TextBoxMaximalNetLatency.Text = "2000"
        Me.SettingsToolTip.SetToolTip(Me.TextBoxMaximalNetLatency, "Auto Power Delay for Output 2")
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(231, 92)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(32, 13)
        Me.Label20.TabIndex = 21
        Me.Label20.Text = "msec"
        '
        'LabelMaximalNetLatency
        '
        Me.LabelMaximalNetLatency.AutoSize = True
        Me.LabelMaximalNetLatency.Location = New System.Drawing.Point(20, 92)
        Me.LabelMaximalNetLatency.Name = "LabelMaximalNetLatency"
        Me.LabelMaximalNetLatency.Size = New System.Drawing.Size(99, 13)
        Me.LabelMaximalNetLatency.TabIndex = 19
        Me.LabelMaximalNetLatency.Text = "Robot stop timeout:"
        '
        'tiltTimerIntervalTextBox
        '
        Me.tiltTimerIntervalTextBox.Location = New System.Drawing.Point(125, 65)
        Me.tiltTimerIntervalTextBox.Name = "tiltTimerIntervalTextBox"
        Me.tiltTimerIntervalTextBox.Size = New System.Drawing.Size(79, 20)
        Me.tiltTimerIntervalTextBox.TabIndex = 16
        Me.tiltTimerIntervalTextBox.Text = "2000"
        Me.SettingsToolTip.SetToolTip(Me.tiltTimerIntervalTextBox, "Auto Power Delay for Output 2")
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(231, 68)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(32, 13)
        Me.Label33.TabIndex = 18
        Me.Label33.Text = "msec"
        '
        'panTimerIntervalTextBox
        '
        Me.panTimerIntervalTextBox.Location = New System.Drawing.Point(125, 41)
        Me.panTimerIntervalTextBox.Name = "panTimerIntervalTextBox"
        Me.panTimerIntervalTextBox.Size = New System.Drawing.Size(79, 20)
        Me.panTimerIntervalTextBox.TabIndex = 15
        Me.panTimerIntervalTextBox.Text = "8000"
        Me.SettingsToolTip.SetToolTip(Me.panTimerIntervalTextBox, "Auto Power Delay for Output 1")
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(65, 68)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(54, 13)
        Me.Label34.TabIndex = 14
        Me.Label34.Text = "Tilt Delay:"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(231, 44)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(32, 13)
        Me.Label35.TabIndex = 17
        Me.Label35.Text = "msec"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(60, 44)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(59, 13)
        Me.Label36.TabIndex = 13
        Me.Label36.Text = "Pan Delay:"
        '
        'txTimerIntervalTextBox
        '
        Me.txTimerIntervalTextBox.Location = New System.Drawing.Point(125, 17)
        Me.txTimerIntervalTextBox.Name = "txTimerIntervalTextBox"
        Me.txTimerIntervalTextBox.Size = New System.Drawing.Size(100, 20)
        Me.txTimerIntervalTextBox.TabIndex = 11
        Me.txTimerIntervalTextBox.Text = "200"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(231, 20)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(32, 13)
        Me.Label21.TabIndex = 12
        Me.Label21.Text = "msec"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(30, 20)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(89, 13)
        Me.Label22.TabIndex = 11
        Me.Label22.Text = "Tx Timer Interval:"
        '
        'updateAndCloseButton
        '
        Me.updateAndCloseButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.updateAndCloseButton.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.updateAndCloseButton.Location = New System.Drawing.Point(371, 278)
        Me.updateAndCloseButton.Name = "updateAndCloseButton"
        Me.updateAndCloseButton.Size = New System.Drawing.Size(122, 30)
        Me.updateAndCloseButton.TabIndex = 31
        Me.updateAndCloseButton.Text = "Update and close"
        Me.updateAndCloseButton.UseVisualStyleBackColor = True
        '
        'cancelFormButton
        '
        Me.cancelFormButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cancelFormButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cancelFormButton.Location = New System.Drawing.Point(499, 278)
        Me.cancelFormButton.Name = "cancelFormButton"
        Me.cancelFormButton.Size = New System.Drawing.Size(122, 30)
        Me.cancelFormButton.TabIndex = 30
        Me.cancelFormButton.Text = "Cancel"
        Me.cancelFormButton.UseVisualStyleBackColor = True
        '
        'CommunicationGroupBox
        '
        Me.CommunicationGroupBox.Controls.Add(Me.dataCOMComboBox)
        Me.CommunicationGroupBox.Controls.Add(Me.dataAutoCheckBox)
        Me.CommunicationGroupBox.Controls.Add(Me.dataLabel)
        Me.CommunicationGroupBox.Location = New System.Drawing.Point(316, 129)
        Me.CommunicationGroupBox.Name = "CommunicationGroupBox"
        Me.CommunicationGroupBox.Size = New System.Drawing.Size(302, 53)
        Me.CommunicationGroupBox.TabIndex = 14
        Me.CommunicationGroupBox.TabStop = False
        Me.CommunicationGroupBox.Text = "Communication Settings"
        '
        'dataCOMComboBox
        '
        Me.dataCOMComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.dataCOMComboBox.FormattingEnabled = True
        Me.dataCOMComboBox.Items.AddRange(New Object() {"", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "COM10", "COM11", "COM12", "COM13", "COM14", "COM15", "COM16"})
        Me.dataCOMComboBox.Location = New System.Drawing.Point(125, 21)
        Me.dataCOMComboBox.Name = "dataCOMComboBox"
        Me.dataCOMComboBox.Size = New System.Drawing.Size(66, 21)
        Me.dataCOMComboBox.TabIndex = 13
        Me.SettingsToolTip.SetToolTip(Me.dataCOMComboBox, "Set Comm Port")
        '
        'dataAutoCheckBox
        '
        Me.dataAutoCheckBox.AutoSize = True
        Me.dataAutoCheckBox.Location = New System.Drawing.Point(203, 23)
        Me.dataAutoCheckBox.Name = "dataAutoCheckBox"
        Me.dataAutoCheckBox.Size = New System.Drawing.Size(87, 17)
        Me.dataAutoCheckBox.TabIndex = 14
        Me.dataAutoCheckBox.Text = "Autoconnect"
        Me.SettingsToolTip.SetToolTip(Me.dataAutoCheckBox, "Toggle Comm Port On on Application Startup")
        Me.dataAutoCheckBox.UseVisualStyleBackColor = True
        Me.dataAutoCheckBox.Visible = False
        '
        'dataLabel
        '
        Me.dataLabel.AutoSize = True
        Me.dataLabel.Location = New System.Drawing.Point(29, 24)
        Me.dataLabel.Name = "dataLabel"
        Me.dataLabel.Size = New System.Drawing.Size(79, 13)
        Me.dataLabel.TabIndex = 8
        Me.dataLabel.Text = "Data COM Port"
        '
        'EncoderCalibrationGroupBox
        '
        Me.EncoderCalibrationGroupBox.Controls.Add(Me.RadioButtonEncoderUnitMetric)
        Me.EncoderCalibrationGroupBox.Controls.Add(Me.RadioButtonEncoderUnitImperial)
        Me.EncoderCalibrationGroupBox.Controls.Add(Me.LabelEncoderUnits)
        Me.EncoderCalibrationGroupBox.Controls.Add(Me.LeftEncoderCalibrationTextBox)
        Me.EncoderCalibrationGroupBox.Controls.Add(Me.lecCountInchLabel)
        Me.EncoderCalibrationGroupBox.Controls.Add(Me.LeftEncoderCalibrationLabel)
        Me.EncoderCalibrationGroupBox.Controls.Add(Me.RightEncoderCalibrationTextBox)
        Me.EncoderCalibrationGroupBox.Controls.Add(Me.recCountInchLabel)
        Me.EncoderCalibrationGroupBox.Controls.Add(Me.RightEncoderCalibrationLabel)
        Me.EncoderCalibrationGroupBox.Location = New System.Drawing.Point(8, 6)
        Me.EncoderCalibrationGroupBox.Name = "EncoderCalibrationGroupBox"
        Me.EncoderCalibrationGroupBox.Size = New System.Drawing.Size(302, 100)
        Me.EncoderCalibrationGroupBox.TabIndex = 32
        Me.EncoderCalibrationGroupBox.TabStop = False
        Me.EncoderCalibrationGroupBox.Text = "Encoder Calibration"
        '
        'RadioButtonEncoderUnitMetric
        '
        Me.RadioButtonEncoderUnitMetric.AutoSize = True
        Me.RadioButtonEncoderUnitMetric.Location = New System.Drawing.Point(176, 72)
        Me.RadioButtonEncoderUnitMetric.Name = "RadioButtonEncoderUnitMetric"
        Me.RadioButtonEncoderUnitMetric.Size = New System.Drawing.Size(80, 17)
        Me.RadioButtonEncoderUnitMetric.TabIndex = 43
        Me.RadioButtonEncoderUnitMetric.TabStop = True
        Me.RadioButtonEncoderUnitMetric.Text = "Centimeters"
        Me.RadioButtonEncoderUnitMetric.UseVisualStyleBackColor = True
        '
        'RadioButtonEncoderUnitImperial
        '
        Me.RadioButtonEncoderUnitImperial.AutoSize = True
        Me.RadioButtonEncoderUnitImperial.Location = New System.Drawing.Point(103, 72)
        Me.RadioButtonEncoderUnitImperial.Name = "RadioButtonEncoderUnitImperial"
        Me.RadioButtonEncoderUnitImperial.Size = New System.Drawing.Size(57, 17)
        Me.RadioButtonEncoderUnitImperial.TabIndex = 42
        Me.RadioButtonEncoderUnitImperial.TabStop = True
        Me.RadioButtonEncoderUnitImperial.Text = "Inches"
        Me.RadioButtonEncoderUnitImperial.UseVisualStyleBackColor = True
        '
        'LabelEncoderUnits
        '
        Me.LabelEncoderUnits.AutoSize = True
        Me.LabelEncoderUnits.Location = New System.Drawing.Point(63, 74)
        Me.LabelEncoderUnits.Name = "LabelEncoderUnits"
        Me.LabelEncoderUnits.Size = New System.Drawing.Size(34, 13)
        Me.LabelEncoderUnits.TabIndex = 41
        Me.LabelEncoderUnits.Text = "Units:"
        '
        'LeftEncoderCalibrationTextBox
        '
        Me.LeftEncoderCalibrationTextBox.Location = New System.Drawing.Point(103, 45)
        Me.LeftEncoderCalibrationTextBox.Name = "LeftEncoderCalibrationTextBox"
        Me.LeftEncoderCalibrationTextBox.Size = New System.Drawing.Size(100, 20)
        Me.LeftEncoderCalibrationTextBox.TabIndex = 37
        Me.LeftEncoderCalibrationTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.LeftEncoderCalibrationTextBox, "Encoder Calibration Value")
        '
        'lecCountInchLabel
        '
        Me.lecCountInchLabel.AutoSize = True
        Me.lecCountInchLabel.Location = New System.Drawing.Point(209, 48)
        Me.lecCountInchLabel.Name = "lecCountInchLabel"
        Me.lecCountInchLabel.Size = New System.Drawing.Size(65, 13)
        Me.lecCountInchLabel.TabIndex = 39
        Me.lecCountInchLabel.Text = "Counts/inch"
        '
        'LeftEncoderCalibrationLabel
        '
        Me.LeftEncoderCalibrationLabel.AutoSize = True
        Me.LeftEncoderCalibrationLabel.Location = New System.Drawing.Point(26, 48)
        Me.LeftEncoderCalibrationLabel.Name = "LeftEncoderCalibrationLabel"
        Me.LeftEncoderCalibrationLabel.Size = New System.Drawing.Size(71, 13)
        Me.LeftEncoderCalibrationLabel.TabIndex = 38
        Me.LeftEncoderCalibrationLabel.Text = "Left Encoder:"
        '
        'RightEncoderCalibrationTextBox
        '
        Me.RightEncoderCalibrationTextBox.Location = New System.Drawing.Point(103, 19)
        Me.RightEncoderCalibrationTextBox.Name = "RightEncoderCalibrationTextBox"
        Me.RightEncoderCalibrationTextBox.Size = New System.Drawing.Size(100, 20)
        Me.RightEncoderCalibrationTextBox.TabIndex = 34
        Me.RightEncoderCalibrationTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.RightEncoderCalibrationTextBox, "Encoder Calibration Value")
        '
        'recCountInchLabel
        '
        Me.recCountInchLabel.AutoSize = True
        Me.recCountInchLabel.Location = New System.Drawing.Point(209, 22)
        Me.recCountInchLabel.Name = "recCountInchLabel"
        Me.recCountInchLabel.Size = New System.Drawing.Size(65, 13)
        Me.recCountInchLabel.TabIndex = 36
        Me.recCountInchLabel.Text = "Counts/inch"
        '
        'RightEncoderCalibrationLabel
        '
        Me.RightEncoderCalibrationLabel.AutoSize = True
        Me.RightEncoderCalibrationLabel.Location = New System.Drawing.Point(19, 22)
        Me.RightEncoderCalibrationLabel.Name = "RightEncoderCalibrationLabel"
        Me.RightEncoderCalibrationLabel.Size = New System.Drawing.Size(78, 13)
        Me.RightEncoderCalibrationLabel.TabIndex = 35
        Me.RightEncoderCalibrationLabel.Text = "Right Encoder:"
        '
        'OutputsGroupBox
        '
        Me.OutputsGroupBox.Controls.Add(Me.Output4CheckBox)
        Me.OutputsGroupBox.Controls.Add(Me.Output3CheckBox)
        Me.OutputsGroupBox.Controls.Add(Me.Output2CheckBox)
        Me.OutputsGroupBox.Controls.Add(Me.Output1CheckBox)
        Me.OutputsGroupBox.Controls.Add(Me.Output4TextBox)
        Me.OutputsGroupBox.Controls.Add(Me.Output3TextBox)
        Me.OutputsGroupBox.Controls.Add(Me.Output2TextBox)
        Me.OutputsGroupBox.Controls.Add(Me.Output1TextBox)
        Me.OutputsGroupBox.Controls.Add(Me.Output4Label)
        Me.OutputsGroupBox.Controls.Add(Me.Output3Label)
        Me.OutputsGroupBox.Controls.Add(Me.Output2Label)
        Me.OutputsGroupBox.Controls.Add(Me.Output1Label)
        Me.OutputsGroupBox.Location = New System.Drawing.Point(8, 6)
        Me.OutputsGroupBox.Name = "OutputsGroupBox"
        Me.OutputsGroupBox.Size = New System.Drawing.Size(136, 125)
        Me.OutputsGroupBox.TabIndex = 33
        Me.OutputsGroupBox.TabStop = False
        Me.OutputsGroupBox.Text = "Outputs"
        '
        'Output4CheckBox
        '
        Me.Output4CheckBox.AutoSize = True
        Me.Output4CheckBox.Location = New System.Drawing.Point(110, 99)
        Me.Output4CheckBox.Name = "Output4CheckBox"
        Me.Output4CheckBox.Size = New System.Drawing.Size(15, 14)
        Me.Output4CheckBox.TabIndex = 11
        Me.SettingsToolTip.SetToolTip(Me.Output4CheckBox, "Enable/Disable Output")
        Me.Output4CheckBox.UseVisualStyleBackColor = True
        '
        'Output3CheckBox
        '
        Me.Output3CheckBox.AutoSize = True
        Me.Output3CheckBox.Location = New System.Drawing.Point(110, 73)
        Me.Output3CheckBox.Name = "Output3CheckBox"
        Me.Output3CheckBox.Size = New System.Drawing.Size(15, 14)
        Me.Output3CheckBox.TabIndex = 10
        Me.SettingsToolTip.SetToolTip(Me.Output3CheckBox, "Enable/Disable Output")
        Me.Output3CheckBox.UseVisualStyleBackColor = True
        '
        'Output2CheckBox
        '
        Me.Output2CheckBox.AutoSize = True
        Me.Output2CheckBox.Location = New System.Drawing.Point(110, 47)
        Me.Output2CheckBox.Name = "Output2CheckBox"
        Me.Output2CheckBox.Size = New System.Drawing.Size(15, 14)
        Me.Output2CheckBox.TabIndex = 9
        Me.SettingsToolTip.SetToolTip(Me.Output2CheckBox, "Enable/Disable Output")
        Me.Output2CheckBox.UseVisualStyleBackColor = True
        '
        'Output1CheckBox
        '
        Me.Output1CheckBox.AutoSize = True
        Me.Output1CheckBox.Location = New System.Drawing.Point(110, 21)
        Me.Output1CheckBox.Name = "Output1CheckBox"
        Me.Output1CheckBox.Size = New System.Drawing.Size(15, 14)
        Me.Output1CheckBox.TabIndex = 8
        Me.SettingsToolTip.SetToolTip(Me.Output1CheckBox, "Enable/Disable Output")
        Me.Output1CheckBox.UseVisualStyleBackColor = True
        '
        'Output4TextBox
        '
        Me.Output4TextBox.Location = New System.Drawing.Point(22, 96)
        Me.Output4TextBox.Name = "Output4TextBox"
        Me.Output4TextBox.Size = New System.Drawing.Size(82, 20)
        Me.Output4TextBox.TabIndex = 7
        Me.Output4TextBox.Text = "Output #4"
        Me.SettingsToolTip.SetToolTip(Me.Output4TextBox, "Output Label")
        '
        'Output3TextBox
        '
        Me.Output3TextBox.Location = New System.Drawing.Point(22, 70)
        Me.Output3TextBox.Name = "Output3TextBox"
        Me.Output3TextBox.Size = New System.Drawing.Size(82, 20)
        Me.Output3TextBox.TabIndex = 6
        Me.Output3TextBox.Text = "Output #3"
        Me.SettingsToolTip.SetToolTip(Me.Output3TextBox, "Output Label")
        '
        'Output2TextBox
        '
        Me.Output2TextBox.Location = New System.Drawing.Point(22, 44)
        Me.Output2TextBox.Name = "Output2TextBox"
        Me.Output2TextBox.Size = New System.Drawing.Size(82, 20)
        Me.Output2TextBox.TabIndex = 5
        Me.Output2TextBox.Text = "Output #2"
        Me.SettingsToolTip.SetToolTip(Me.Output2TextBox, "Output Label")
        '
        'Output1TextBox
        '
        Me.Output1TextBox.Location = New System.Drawing.Point(22, 18)
        Me.Output1TextBox.Name = "Output1TextBox"
        Me.Output1TextBox.Size = New System.Drawing.Size(82, 20)
        Me.Output1TextBox.TabIndex = 4
        Me.Output1TextBox.Text = "Output #1"
        Me.SettingsToolTip.SetToolTip(Me.Output1TextBox, "Output Label")
        '
        'Output4Label
        '
        Me.Output4Label.AutoSize = True
        Me.Output4Label.Location = New System.Drawing.Point(6, 99)
        Me.Output4Label.Name = "Output4Label"
        Me.Output4Label.Size = New System.Drawing.Size(16, 13)
        Me.Output4Label.TabIndex = 3
        Me.Output4Label.Text = "4:"
        '
        'Output3Label
        '
        Me.Output3Label.AutoSize = True
        Me.Output3Label.Location = New System.Drawing.Point(6, 73)
        Me.Output3Label.Name = "Output3Label"
        Me.Output3Label.Size = New System.Drawing.Size(16, 13)
        Me.Output3Label.TabIndex = 2
        Me.Output3Label.Text = "3:"
        '
        'Output2Label
        '
        Me.Output2Label.AutoSize = True
        Me.Output2Label.Location = New System.Drawing.Point(6, 47)
        Me.Output2Label.Name = "Output2Label"
        Me.Output2Label.Size = New System.Drawing.Size(16, 13)
        Me.Output2Label.TabIndex = 1
        Me.Output2Label.Text = "2:"
        '
        'Output1Label
        '
        Me.Output1Label.AutoSize = True
        Me.Output1Label.Location = New System.Drawing.Point(6, 21)
        Me.Output1Label.Name = "Output1Label"
        Me.Output1Label.Size = New System.Drawing.Size(16, 13)
        Me.Output1Label.TabIndex = 0
        Me.Output1Label.Text = "1:"
        '
        'AnalogInputsGroupBox
        '
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput3ScaleTextBox)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput3ScaleLabel)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput2ScaleTextBox)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput2ScaleLabel)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput1ScaleTextBox)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput1ScaleLabel)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput3UnitTextBox)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput2UnitTextBox)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput1UnitTextBox)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput3CheckBox)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput2CheckBox)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput1CheckBox)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput3TextBox)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput2TextBox)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput1TextBox)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput3Label)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput2Label)
        Me.AnalogInputsGroupBox.Controls.Add(Me.AnalogInput1Label)
        Me.AnalogInputsGroupBox.Location = New System.Drawing.Point(8, 135)
        Me.AnalogInputsGroupBox.Name = "AnalogInputsGroupBox"
        Me.AnalogInputsGroupBox.Size = New System.Drawing.Size(302, 100)
        Me.AnalogInputsGroupBox.TabIndex = 35
        Me.AnalogInputsGroupBox.TabStop = False
        Me.AnalogInputsGroupBox.Text = "Analog Inputs*"
        '
        'AnalogInput3ScaleTextBox
        '
        Me.AnalogInput3ScaleTextBox.Location = New System.Drawing.Point(188, 70)
        Me.AnalogInput3ScaleTextBox.Name = "AnalogInput3ScaleTextBox"
        Me.AnalogInput3ScaleTextBox.Size = New System.Drawing.Size(82, 20)
        Me.AnalogInput3ScaleTextBox.TabIndex = 28
        Me.AnalogInput3ScaleTextBox.Text = "10"
        '
        'AnalogInput3ScaleLabel
        '
        Me.AnalogInput3ScaleLabel.AutoSize = True
        Me.AnalogInput3ScaleLabel.Location = New System.Drawing.Point(147, 73)
        Me.AnalogInput3ScaleLabel.Name = "AnalogInput3ScaleLabel"
        Me.AnalogInput3ScaleLabel.Size = New System.Drawing.Size(37, 13)
        Me.AnalogInput3ScaleLabel.TabIndex = 27
        Me.AnalogInput3ScaleLabel.Text = "Scale:"
        '
        'AnalogInput2ScaleTextBox
        '
        Me.AnalogInput2ScaleTextBox.Location = New System.Drawing.Point(188, 44)
        Me.AnalogInput2ScaleTextBox.Name = "AnalogInput2ScaleTextBox"
        Me.AnalogInput2ScaleTextBox.Size = New System.Drawing.Size(82, 20)
        Me.AnalogInput2ScaleTextBox.TabIndex = 26
        Me.AnalogInput2ScaleTextBox.Text = "10"
        '
        'AnalogInput2ScaleLabel
        '
        Me.AnalogInput2ScaleLabel.AutoSize = True
        Me.AnalogInput2ScaleLabel.Location = New System.Drawing.Point(147, 47)
        Me.AnalogInput2ScaleLabel.Name = "AnalogInput2ScaleLabel"
        Me.AnalogInput2ScaleLabel.Size = New System.Drawing.Size(37, 13)
        Me.AnalogInput2ScaleLabel.TabIndex = 25
        Me.AnalogInput2ScaleLabel.Text = "Scale:"
        '
        'AnalogInput1ScaleTextBox
        '
        Me.AnalogInput1ScaleTextBox.Location = New System.Drawing.Point(188, 18)
        Me.AnalogInput1ScaleTextBox.Name = "AnalogInput1ScaleTextBox"
        Me.AnalogInput1ScaleTextBox.Size = New System.Drawing.Size(82, 20)
        Me.AnalogInput1ScaleTextBox.TabIndex = 24
        Me.AnalogInput1ScaleTextBox.Text = "10"
        '
        'AnalogInput1ScaleLabel
        '
        Me.AnalogInput1ScaleLabel.AutoSize = True
        Me.AnalogInput1ScaleLabel.Location = New System.Drawing.Point(147, 21)
        Me.AnalogInput1ScaleLabel.Name = "AnalogInput1ScaleLabel"
        Me.AnalogInput1ScaleLabel.Size = New System.Drawing.Size(37, 13)
        Me.AnalogInput1ScaleLabel.TabIndex = 23
        Me.AnalogInput1ScaleLabel.Text = "Scale:"
        '
        'AnalogInput3UnitTextBox
        '
        Me.AnalogInput3UnitTextBox.Location = New System.Drawing.Point(110, 71)
        Me.AnalogInput3UnitTextBox.Name = "AnalogInput3UnitTextBox"
        Me.AnalogInput3UnitTextBox.Size = New System.Drawing.Size(14, 20)
        Me.AnalogInput3UnitTextBox.TabIndex = 22
        Me.AnalogInput3UnitTextBox.Text = "A"
        Me.AnalogInput3UnitTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.SettingsToolTip.SetToolTip(Me.AnalogInput3UnitTextBox, "Analog Input Label for Units")
        '
        'AnalogInput2UnitTextBox
        '
        Me.AnalogInput2UnitTextBox.Location = New System.Drawing.Point(110, 45)
        Me.AnalogInput2UnitTextBox.Name = "AnalogInput2UnitTextBox"
        Me.AnalogInput2UnitTextBox.Size = New System.Drawing.Size(14, 20)
        Me.AnalogInput2UnitTextBox.TabIndex = 21
        Me.AnalogInput2UnitTextBox.Text = "V"
        Me.AnalogInput2UnitTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.SettingsToolTip.SetToolTip(Me.AnalogInput2UnitTextBox, "Analog Input Label for Units")
        '
        'AnalogInput1UnitTextBox
        '
        Me.AnalogInput1UnitTextBox.Location = New System.Drawing.Point(110, 19)
        Me.AnalogInput1UnitTextBox.Name = "AnalogInput1UnitTextBox"
        Me.AnalogInput1UnitTextBox.Size = New System.Drawing.Size(14, 20)
        Me.AnalogInput1UnitTextBox.TabIndex = 20
        Me.AnalogInput1UnitTextBox.Text = "V"
        Me.AnalogInput1UnitTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.SettingsToolTip.SetToolTip(Me.AnalogInput1UnitTextBox, "Analog Input Label for Units")
        '
        'AnalogInput3CheckBox
        '
        Me.AnalogInput3CheckBox.AutoSize = True
        Me.AnalogInput3CheckBox.Location = New System.Drawing.Point(276, 73)
        Me.AnalogInput3CheckBox.Name = "AnalogInput3CheckBox"
        Me.AnalogInput3CheckBox.Size = New System.Drawing.Size(15, 14)
        Me.AnalogInput3CheckBox.TabIndex = 19
        Me.SettingsToolTip.SetToolTip(Me.AnalogInput3CheckBox, "Enable/Disable Input - See note 1")
        Me.AnalogInput3CheckBox.UseVisualStyleBackColor = True
        '
        'AnalogInput2CheckBox
        '
        Me.AnalogInput2CheckBox.AutoSize = True
        Me.AnalogInput2CheckBox.Location = New System.Drawing.Point(276, 47)
        Me.AnalogInput2CheckBox.Name = "AnalogInput2CheckBox"
        Me.AnalogInput2CheckBox.Size = New System.Drawing.Size(15, 14)
        Me.AnalogInput2CheckBox.TabIndex = 18
        Me.SettingsToolTip.SetToolTip(Me.AnalogInput2CheckBox, "Enable/Disable Input - See note 1")
        Me.AnalogInput2CheckBox.UseVisualStyleBackColor = True
        '
        'AnalogInput1CheckBox
        '
        Me.AnalogInput1CheckBox.AutoSize = True
        Me.AnalogInput1CheckBox.Location = New System.Drawing.Point(276, 21)
        Me.AnalogInput1CheckBox.Name = "AnalogInput1CheckBox"
        Me.AnalogInput1CheckBox.Size = New System.Drawing.Size(15, 14)
        Me.AnalogInput1CheckBox.TabIndex = 17
        Me.SettingsToolTip.SetToolTip(Me.AnalogInput1CheckBox, "Enable/Disable Input - See note 1")
        Me.AnalogInput1CheckBox.UseVisualStyleBackColor = True
        '
        'AnalogInput3TextBox
        '
        Me.AnalogInput3TextBox.Location = New System.Drawing.Point(22, 71)
        Me.AnalogInput3TextBox.Name = "AnalogInput3TextBox"
        Me.AnalogInput3TextBox.Size = New System.Drawing.Size(82, 20)
        Me.AnalogInput3TextBox.TabIndex = 16
        Me.AnalogInput3TextBox.Text = "Current:"
        Me.SettingsToolTip.SetToolTip(Me.AnalogInput3TextBox, "Analog Input Label")
        '
        'AnalogInput2TextBox
        '
        Me.AnalogInput2TextBox.Location = New System.Drawing.Point(22, 45)
        Me.AnalogInput2TextBox.Name = "AnalogInput2TextBox"
        Me.AnalogInput2TextBox.Size = New System.Drawing.Size(82, 20)
        Me.AnalogInput2TextBox.TabIndex = 15
        Me.AnalogInput2TextBox.Text = "Control:"
        Me.SettingsToolTip.SetToolTip(Me.AnalogInput2TextBox, "Analog Input Label")
        '
        'AnalogInput1TextBox
        '
        Me.AnalogInput1TextBox.Location = New System.Drawing.Point(22, 19)
        Me.AnalogInput1TextBox.Name = "AnalogInput1TextBox"
        Me.AnalogInput1TextBox.Size = New System.Drawing.Size(82, 20)
        Me.AnalogInput1TextBox.TabIndex = 14
        Me.AnalogInput1TextBox.Text = "Drive:"
        Me.SettingsToolTip.SetToolTip(Me.AnalogInput1TextBox, "Analog Input Label")
        '
        'AnalogInput3Label
        '
        Me.AnalogInput3Label.AutoSize = True
        Me.AnalogInput3Label.Location = New System.Drawing.Point(6, 74)
        Me.AnalogInput3Label.Name = "AnalogInput3Label"
        Me.AnalogInput3Label.Size = New System.Drawing.Size(16, 13)
        Me.AnalogInput3Label.TabIndex = 13
        Me.AnalogInput3Label.Text = "3:"
        '
        'AnalogInput2Label
        '
        Me.AnalogInput2Label.AutoSize = True
        Me.AnalogInput2Label.Location = New System.Drawing.Point(6, 48)
        Me.AnalogInput2Label.Name = "AnalogInput2Label"
        Me.AnalogInput2Label.Size = New System.Drawing.Size(16, 13)
        Me.AnalogInput2Label.TabIndex = 12
        Me.AnalogInput2Label.Text = "2:"
        '
        'AnalogInput1Label
        '
        Me.AnalogInput1Label.AutoSize = True
        Me.AnalogInput1Label.Location = New System.Drawing.Point(6, 22)
        Me.AnalogInput1Label.Name = "AnalogInput1Label"
        Me.AnalogInput1Label.Size = New System.Drawing.Size(16, 13)
        Me.AnalogInput1Label.TabIndex = 11
        Me.AnalogInput1Label.Text = "1:"
        '
        'DigitalInputsGroupBox
        '
        Me.DigitalInputsGroupBox.Controls.Add(Me.DigitalInput4CheckBox)
        Me.DigitalInputsGroupBox.Controls.Add(Me.DigitalInput3CheckBox)
        Me.DigitalInputsGroupBox.Controls.Add(Me.DigitalInput2CheckBox)
        Me.DigitalInputsGroupBox.Controls.Add(Me.DigitalInput1CheckBox)
        Me.DigitalInputsGroupBox.Controls.Add(Me.DigitalInput4TextBox)
        Me.DigitalInputsGroupBox.Controls.Add(Me.DigitalInput3TextBox)
        Me.DigitalInputsGroupBox.Controls.Add(Me.DigitalInput2TextBox)
        Me.DigitalInputsGroupBox.Controls.Add(Me.DigitalInput1TextBox)
        Me.DigitalInputsGroupBox.Controls.Add(Me.DigitalInput4Label)
        Me.DigitalInputsGroupBox.Controls.Add(Me.DigitalInput3Label)
        Me.DigitalInputsGroupBox.Controls.Add(Me.DigitalInput2Label)
        Me.DigitalInputsGroupBox.Controls.Add(Me.DigitalInput1Label)
        Me.DigitalInputsGroupBox.Location = New System.Drawing.Point(174, 6)
        Me.DigitalInputsGroupBox.Name = "DigitalInputsGroupBox"
        Me.DigitalInputsGroupBox.Size = New System.Drawing.Size(136, 125)
        Me.DigitalInputsGroupBox.TabIndex = 34
        Me.DigitalInputsGroupBox.TabStop = False
        Me.DigitalInputsGroupBox.Text = "Digital Inputs*"
        '
        'DigitalInput4CheckBox
        '
        Me.DigitalInput4CheckBox.AutoSize = True
        Me.DigitalInput4CheckBox.Location = New System.Drawing.Point(110, 99)
        Me.DigitalInput4CheckBox.Name = "DigitalInput4CheckBox"
        Me.DigitalInput4CheckBox.Size = New System.Drawing.Size(15, 14)
        Me.DigitalInput4CheckBox.TabIndex = 11
        Me.SettingsToolTip.SetToolTip(Me.DigitalInput4CheckBox, "Enable/Disable Input - See note 1")
        Me.DigitalInput4CheckBox.UseVisualStyleBackColor = True
        '
        'DigitalInput3CheckBox
        '
        Me.DigitalInput3CheckBox.AutoSize = True
        Me.DigitalInput3CheckBox.Location = New System.Drawing.Point(110, 73)
        Me.DigitalInput3CheckBox.Name = "DigitalInput3CheckBox"
        Me.DigitalInput3CheckBox.Size = New System.Drawing.Size(15, 14)
        Me.DigitalInput3CheckBox.TabIndex = 10
        Me.SettingsToolTip.SetToolTip(Me.DigitalInput3CheckBox, "Enable/Disable Input - See note 1")
        Me.DigitalInput3CheckBox.UseVisualStyleBackColor = True
        '
        'DigitalInput2CheckBox
        '
        Me.DigitalInput2CheckBox.AutoSize = True
        Me.DigitalInput2CheckBox.Location = New System.Drawing.Point(110, 47)
        Me.DigitalInput2CheckBox.Name = "DigitalInput2CheckBox"
        Me.DigitalInput2CheckBox.Size = New System.Drawing.Size(15, 14)
        Me.DigitalInput2CheckBox.TabIndex = 9
        Me.SettingsToolTip.SetToolTip(Me.DigitalInput2CheckBox, "Enable/Disable Input - See note 1")
        Me.DigitalInput2CheckBox.UseVisualStyleBackColor = True
        '
        'DigitalInput1CheckBox
        '
        Me.DigitalInput1CheckBox.AutoSize = True
        Me.DigitalInput1CheckBox.Location = New System.Drawing.Point(110, 21)
        Me.DigitalInput1CheckBox.Name = "DigitalInput1CheckBox"
        Me.DigitalInput1CheckBox.Size = New System.Drawing.Size(15, 14)
        Me.DigitalInput1CheckBox.TabIndex = 8
        Me.SettingsToolTip.SetToolTip(Me.DigitalInput1CheckBox, "Enable/Disable Input - See note 1")
        Me.DigitalInput1CheckBox.UseVisualStyleBackColor = True
        '
        'DigitalInput4TextBox
        '
        Me.DigitalInput4TextBox.Location = New System.Drawing.Point(22, 96)
        Me.DigitalInput4TextBox.Name = "DigitalInput4TextBox"
        Me.DigitalInput4TextBox.Size = New System.Drawing.Size(82, 20)
        Me.DigitalInput4TextBox.TabIndex = 7
        Me.DigitalInput4TextBox.Text = "Input #4"
        Me.SettingsToolTip.SetToolTip(Me.DigitalInput4TextBox, "Input Label")
        '
        'DigitalInput3TextBox
        '
        Me.DigitalInput3TextBox.Location = New System.Drawing.Point(22, 70)
        Me.DigitalInput3TextBox.Name = "DigitalInput3TextBox"
        Me.DigitalInput3TextBox.Size = New System.Drawing.Size(82, 20)
        Me.DigitalInput3TextBox.TabIndex = 6
        Me.DigitalInput3TextBox.Text = "Input #3"
        Me.SettingsToolTip.SetToolTip(Me.DigitalInput3TextBox, "Input Label")
        '
        'DigitalInput2TextBox
        '
        Me.DigitalInput2TextBox.Location = New System.Drawing.Point(22, 44)
        Me.DigitalInput2TextBox.Name = "DigitalInput2TextBox"
        Me.DigitalInput2TextBox.Size = New System.Drawing.Size(82, 20)
        Me.DigitalInput2TextBox.TabIndex = 5
        Me.DigitalInput2TextBox.Text = "Input #2"
        Me.SettingsToolTip.SetToolTip(Me.DigitalInput2TextBox, "Input Label")
        '
        'DigitalInput1TextBox
        '
        Me.DigitalInput1TextBox.Location = New System.Drawing.Point(22, 18)
        Me.DigitalInput1TextBox.Name = "DigitalInput1TextBox"
        Me.DigitalInput1TextBox.Size = New System.Drawing.Size(82, 20)
        Me.DigitalInput1TextBox.TabIndex = 4
        Me.DigitalInput1TextBox.Text = "Input #1"
        Me.SettingsToolTip.SetToolTip(Me.DigitalInput1TextBox, "Input Label")
        '
        'DigitalInput4Label
        '
        Me.DigitalInput4Label.AutoSize = True
        Me.DigitalInput4Label.Location = New System.Drawing.Point(6, 99)
        Me.DigitalInput4Label.Name = "DigitalInput4Label"
        Me.DigitalInput4Label.Size = New System.Drawing.Size(16, 13)
        Me.DigitalInput4Label.TabIndex = 3
        Me.DigitalInput4Label.Text = "4:"
        '
        'DigitalInput3Label
        '
        Me.DigitalInput3Label.AutoSize = True
        Me.DigitalInput3Label.Location = New System.Drawing.Point(6, 73)
        Me.DigitalInput3Label.Name = "DigitalInput3Label"
        Me.DigitalInput3Label.Size = New System.Drawing.Size(16, 13)
        Me.DigitalInput3Label.TabIndex = 2
        Me.DigitalInput3Label.Text = "3:"
        '
        'DigitalInput2Label
        '
        Me.DigitalInput2Label.AutoSize = True
        Me.DigitalInput2Label.Location = New System.Drawing.Point(6, 47)
        Me.DigitalInput2Label.Name = "DigitalInput2Label"
        Me.DigitalInput2Label.Size = New System.Drawing.Size(16, 13)
        Me.DigitalInput2Label.TabIndex = 1
        Me.DigitalInput2Label.Text = "2:"
        '
        'DigitalInput1Label
        '
        Me.DigitalInput1Label.AutoSize = True
        Me.DigitalInput1Label.Location = New System.Drawing.Point(6, 21)
        Me.DigitalInput1Label.Name = "DigitalInput1Label"
        Me.DigitalInput1Label.Size = New System.Drawing.Size(16, 13)
        Me.DigitalInput1Label.TabIndex = 0
        Me.DigitalInput1Label.Text = "1:"
        '
        'AnalogInput3WarningsCheckBox
        '
        Me.AnalogInput3WarningsCheckBox.AutoSize = True
        Me.AnalogInput3WarningsCheckBox.Location = New System.Drawing.Point(276, 66)
        Me.AnalogInput3WarningsCheckBox.Name = "AnalogInput3WarningsCheckBox"
        Me.AnalogInput3WarningsCheckBox.Size = New System.Drawing.Size(15, 14)
        Me.AnalogInput3WarningsCheckBox.TabIndex = 37
        Me.SettingsToolTip.SetToolTip(Me.AnalogInput3WarningsCheckBox, "Enable/Disable Input - See note 1")
        Me.AnalogInput3WarningsCheckBox.UseVisualStyleBackColor = True
        '
        'AnalogInput2WarningsCheckBox
        '
        Me.AnalogInput2WarningsCheckBox.AutoSize = True
        Me.AnalogInput2WarningsCheckBox.Location = New System.Drawing.Point(276, 42)
        Me.AnalogInput2WarningsCheckBox.Name = "AnalogInput2WarningsCheckBox"
        Me.AnalogInput2WarningsCheckBox.Size = New System.Drawing.Size(15, 14)
        Me.AnalogInput2WarningsCheckBox.TabIndex = 36
        Me.SettingsToolTip.SetToolTip(Me.AnalogInput2WarningsCheckBox, "Enable/Disable Input - See note 1")
        Me.AnalogInput2WarningsCheckBox.UseVisualStyleBackColor = True
        '
        'AnalogInput1WarningsCheckBox
        '
        Me.AnalogInput1WarningsCheckBox.AutoSize = True
        Me.AnalogInput1WarningsCheckBox.Location = New System.Drawing.Point(276, 18)
        Me.AnalogInput1WarningsCheckBox.Name = "AnalogInput1WarningsCheckBox"
        Me.AnalogInput1WarningsCheckBox.Size = New System.Drawing.Size(15, 14)
        Me.AnalogInput1WarningsCheckBox.TabIndex = 35
        Me.SettingsToolTip.SetToolTip(Me.AnalogInput1WarningsCheckBox, "Enable/Disable Input - See note 1")
        Me.AnalogInput1WarningsCheckBox.UseVisualStyleBackColor = True
        '
        'AllowedRange3LowTextBox
        '
        Me.AllowedRange3LowTextBox.Location = New System.Drawing.Point(58, 63)
        Me.AllowedRange3LowTextBox.Name = "AllowedRange3LowTextBox"
        Me.AllowedRange3LowTextBox.Size = New System.Drawing.Size(66, 20)
        Me.AllowedRange3LowTextBox.TabIndex = 34
        Me.AllowedRange3LowTextBox.Text = "0"
        Me.SettingsToolTip.SetToolTip(Me.AllowedRange3LowTextBox, "Analog Input Label")
        '
        'AllowedRange2LowTextBox
        '
        Me.AllowedRange2LowTextBox.Location = New System.Drawing.Point(58, 39)
        Me.AllowedRange2LowTextBox.Name = "AllowedRange2LowTextBox"
        Me.AllowedRange2LowTextBox.Size = New System.Drawing.Size(66, 20)
        Me.AllowedRange2LowTextBox.TabIndex = 33
        Me.AllowedRange2LowTextBox.Text = "0"
        Me.SettingsToolTip.SetToolTip(Me.AllowedRange2LowTextBox, "Analog Input Label")
        '
        'AllowedRange1LowTextBox
        '
        Me.AllowedRange1LowTextBox.Location = New System.Drawing.Point(58, 15)
        Me.AllowedRange1LowTextBox.Name = "AllowedRange1LowTextBox"
        Me.AllowedRange1LowTextBox.Size = New System.Drawing.Size(66, 20)
        Me.AllowedRange1LowTextBox.TabIndex = 32
        Me.AllowedRange1LowTextBox.Text = "0"
        Me.SettingsToolTip.SetToolTip(Me.AllowedRange1LowTextBox, "Analog Input Label")
        '
        'CameraIPAddressTextBox
        '
        Me.CameraIPAddressTextBox.Location = New System.Drawing.Point(78, 17)
        Me.CameraIPAddressTextBox.Name = "CameraIPAddressTextBox"
        Me.CameraIPAddressTextBox.Size = New System.Drawing.Size(100, 20)
        Me.CameraIPAddressTextBox.TabIndex = 19
        Me.CameraIPAddressTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.CameraIPAddressTextBox, "Desired Set Point Position")
        '
        'CameraPortTextBox
        '
        Me.CameraPortTextBox.Location = New System.Drawing.Point(228, 17)
        Me.CameraPortTextBox.Name = "CameraPortTextBox"
        Me.CameraPortTextBox.Size = New System.Drawing.Size(62, 20)
        Me.CameraPortTextBox.TabIndex = 22
        Me.CameraPortTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.CameraPortTextBox, "Desired Set Point Position")
        '
        'CameraLoginTextBox
        '
        Me.CameraLoginTextBox.Location = New System.Drawing.Point(26, 36)
        Me.CameraLoginTextBox.Name = "CameraLoginTextBox"
        Me.CameraLoginTextBox.Size = New System.Drawing.Size(30, 20)
        Me.CameraLoginTextBox.TabIndex = 25
        Me.CameraLoginTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.CameraLoginTextBox, "Desired Set Point Position")
        Me.CameraLoginTextBox.Visible = False
        '
        'CameraPasswordTextBox
        '
        Me.CameraPasswordTextBox.Location = New System.Drawing.Point(6, 40)
        Me.CameraPasswordTextBox.Name = "CameraPasswordTextBox"
        Me.CameraPasswordTextBox.Size = New System.Drawing.Size(30, 20)
        Me.CameraPasswordTextBox.TabIndex = 28
        Me.CameraPasswordTextBox.Text = "---"
        Me.SettingsToolTip.SetToolTip(Me.CameraPasswordTextBox, "Desired Set Point Position")
        Me.CameraPasswordTextBox.UseSystemPasswordChar = True
        Me.CameraPasswordTextBox.Visible = False
        '
        'cmbVideoEncodingResolution
        '
        Me.cmbVideoEncodingResolution.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbVideoEncodingResolution.FormattingEnabled = True
        Me.cmbVideoEncodingResolution.Location = New System.Drawing.Point(96, 19)
        Me.cmbVideoEncodingResolution.Name = "cmbVideoEncodingResolution"
        Me.cmbVideoEncodingResolution.Size = New System.Drawing.Size(194, 21)
        Me.cmbVideoEncodingResolution.TabIndex = 28
        Me.SettingsToolTip.SetToolTip(Me.cmbVideoEncodingResolution, "Size of encoded frames")
        '
        'txtVideoFrameCaptureInterval
        '
        Me.txtVideoFrameCaptureInterval.Location = New System.Drawing.Point(214, 179)
        Me.txtVideoFrameCaptureInterval.Name = "txtVideoFrameCaptureInterval"
        Me.txtVideoFrameCaptureInterval.Size = New System.Drawing.Size(76, 20)
        Me.txtVideoFrameCaptureInterval.TabIndex = 33
        Me.SettingsToolTip.SetToolTip(Me.txtVideoFrameCaptureInterval, "Sets the number of frames to skip (no encoding and sending) between each captured" & _
                " frame.")
        '
        'cmbVideoH264SpeedLevel
        '
        Me.cmbVideoH264SpeedLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbVideoH264SpeedLevel.FormattingEnabled = True
        Me.cmbVideoH264SpeedLevel.Items.AddRange(New Object() {"128x96", "176x144", "352x288", "704x576", "1408x1152"})
        Me.cmbVideoH264SpeedLevel.Location = New System.Drawing.Point(96, 46)
        Me.cmbVideoH264SpeedLevel.Name = "cmbVideoH264SpeedLevel"
        Me.cmbVideoH264SpeedLevel.Size = New System.Drawing.Size(194, 21)
        Me.cmbVideoH264SpeedLevel.TabIndex = 37
        Me.SettingsToolTip.SetToolTip(Me.cmbVideoH264SpeedLevel, "This property allows to fine-tune the required Quality to Speed tradeoff")
        '
        'cmbVideoH264Profile
        '
        Me.cmbVideoH264Profile.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbVideoH264Profile.FormattingEnabled = True
        Me.cmbVideoH264Profile.Items.AddRange(New Object() {"128x96", "176x144", "352x288", "704x576", "1408x1152"})
        Me.cmbVideoH264Profile.Location = New System.Drawing.Point(96, 73)
        Me.cmbVideoH264Profile.Name = "cmbVideoH264Profile"
        Me.cmbVideoH264Profile.Size = New System.Drawing.Size(194, 21)
        Me.cmbVideoH264Profile.TabIndex = 38
        Me.SettingsToolTip.SetToolTip(Me.cmbVideoH264Profile, "H.264 Profiles (http://en.wikipedia.org/wiki/H.264#Profiles)")
        '
        'txtVideoFrameRate
        '
        Me.txtVideoFrameRate.Location = New System.Drawing.Point(214, 100)
        Me.txtVideoFrameRate.Name = "txtVideoFrameRate"
        Me.txtVideoFrameRate.Size = New System.Drawing.Size(76, 20)
        Me.txtVideoFrameRate.TabIndex = 36
        Me.SettingsToolTip.SetToolTip(Me.txtVideoFrameRate, "Sets the framerate at which the frames will be encoded")
        '
        'txtVideoIFrameFrequency
        '
        Me.txtVideoIFrameFrequency.Location = New System.Drawing.Point(214, 153)
        Me.txtVideoIFrameFrequency.Name = "txtVideoIFrameFrequency"
        Me.txtVideoIFrameFrequency.Size = New System.Drawing.Size(76, 20)
        Me.txtVideoIFrameFrequency.TabIndex = 32
        Me.SettingsToolTip.SetToolTip(Me.txtVideoIFrameFrequency, "Sets the amount of of P-Frames before another I-Frame will be generated.")
        '
        'txtVideoBitRate
        '
        Me.txtVideoBitRate.Location = New System.Drawing.Point(214, 126)
        Me.txtVideoBitRate.Name = "txtVideoBitRate"
        Me.txtVideoBitRate.Size = New System.Drawing.Size(76, 20)
        Me.txtVideoBitRate.TabIndex = 31
        Me.SettingsToolTip.SetToolTip(Me.txtVideoBitRate, "Sets the bitrate at which the frames will be encoded ")
        '
        'OutOfRangeWarningsGroupBox
        '
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AllowedRange3HighTextBox)
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AnalogInput3WarningsHighLabel)
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AllowedRange2HighTextBox)
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AnalogInput2WarningsHighLabel)
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AllowedRange1HighTextBox)
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AnalogInput1WarningsHighLabel)
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AnalogInput3WarningsCheckBox)
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AnalogInput2WarningsCheckBox)
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AnalogInput1WarningsCheckBox)
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AllowedRange3LowTextBox)
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AllowedRange2LowTextBox)
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AllowedRange1LowTextBox)
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AnalogInput3WarningsLowLabel)
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AnalogInput2WarningsLowLabel)
        Me.OutOfRangeWarningsGroupBox.Controls.Add(Me.AnalogInput1WarningsLowLabel)
        Me.OutOfRangeWarningsGroupBox.Location = New System.Drawing.Point(316, 6)
        Me.OutOfRangeWarningsGroupBox.Name = "OutOfRangeWarningsGroupBox"
        Me.OutOfRangeWarningsGroupBox.Size = New System.Drawing.Size(302, 90)
        Me.OutOfRangeWarningsGroupBox.TabIndex = 37
        Me.OutOfRangeWarningsGroupBox.TabStop = False
        Me.OutOfRangeWarningsGroupBox.Text = "Out Of Range Warnings"
        '
        'AllowedRange3HighTextBox
        '
        Me.AllowedRange3HighTextBox.Location = New System.Drawing.Point(188, 63)
        Me.AllowedRange3HighTextBox.Name = "AllowedRange3HighTextBox"
        Me.AllowedRange3HighTextBox.Size = New System.Drawing.Size(82, 20)
        Me.AllowedRange3HighTextBox.TabIndex = 43
        Me.AllowedRange3HighTextBox.Text = "10"
        '
        'AnalogInput3WarningsHighLabel
        '
        Me.AnalogInput3WarningsHighLabel.AutoSize = True
        Me.AnalogInput3WarningsHighLabel.Location = New System.Drawing.Point(154, 66)
        Me.AnalogInput3WarningsHighLabel.Name = "AnalogInput3WarningsHighLabel"
        Me.AnalogInput3WarningsHighLabel.Size = New System.Drawing.Size(32, 13)
        Me.AnalogInput3WarningsHighLabel.TabIndex = 42
        Me.AnalogInput3WarningsHighLabel.Text = "High:"
        '
        'AllowedRange2HighTextBox
        '
        Me.AllowedRange2HighTextBox.Location = New System.Drawing.Point(188, 39)
        Me.AllowedRange2HighTextBox.Name = "AllowedRange2HighTextBox"
        Me.AllowedRange2HighTextBox.Size = New System.Drawing.Size(82, 20)
        Me.AllowedRange2HighTextBox.TabIndex = 41
        Me.AllowedRange2HighTextBox.Text = "10"
        '
        'AnalogInput2WarningsHighLabel
        '
        Me.AnalogInput2WarningsHighLabel.AutoSize = True
        Me.AnalogInput2WarningsHighLabel.Location = New System.Drawing.Point(154, 42)
        Me.AnalogInput2WarningsHighLabel.Name = "AnalogInput2WarningsHighLabel"
        Me.AnalogInput2WarningsHighLabel.Size = New System.Drawing.Size(32, 13)
        Me.AnalogInput2WarningsHighLabel.TabIndex = 40
        Me.AnalogInput2WarningsHighLabel.Text = "High:"
        '
        'AllowedRange1HighTextBox
        '
        Me.AllowedRange1HighTextBox.Location = New System.Drawing.Point(188, 15)
        Me.AllowedRange1HighTextBox.Name = "AllowedRange1HighTextBox"
        Me.AllowedRange1HighTextBox.Size = New System.Drawing.Size(82, 20)
        Me.AllowedRange1HighTextBox.TabIndex = 39
        Me.AllowedRange1HighTextBox.Text = "10"
        '
        'AnalogInput1WarningsHighLabel
        '
        Me.AnalogInput1WarningsHighLabel.AutoSize = True
        Me.AnalogInput1WarningsHighLabel.Location = New System.Drawing.Point(154, 18)
        Me.AnalogInput1WarningsHighLabel.Name = "AnalogInput1WarningsHighLabel"
        Me.AnalogInput1WarningsHighLabel.Size = New System.Drawing.Size(32, 13)
        Me.AnalogInput1WarningsHighLabel.TabIndex = 38
        Me.AnalogInput1WarningsHighLabel.Text = "High:"
        '
        'AnalogInput3WarningsLowLabel
        '
        Me.AnalogInput3WarningsLowLabel.AutoSize = True
        Me.AnalogInput3WarningsLowLabel.Location = New System.Drawing.Point(7, 66)
        Me.AnalogInput3WarningsLowLabel.Name = "AnalogInput3WarningsLowLabel"
        Me.AnalogInput3WarningsLowLabel.Size = New System.Drawing.Size(45, 13)
        Me.AnalogInput3WarningsLowLabel.TabIndex = 31
        Me.AnalogInput3WarningsLowLabel.Text = "3:  Low:"
        '
        'AnalogInput2WarningsLowLabel
        '
        Me.AnalogInput2WarningsLowLabel.AutoSize = True
        Me.AnalogInput2WarningsLowLabel.Location = New System.Drawing.Point(7, 42)
        Me.AnalogInput2WarningsLowLabel.Name = "AnalogInput2WarningsLowLabel"
        Me.AnalogInput2WarningsLowLabel.Size = New System.Drawing.Size(45, 13)
        Me.AnalogInput2WarningsLowLabel.TabIndex = 30
        Me.AnalogInput2WarningsLowLabel.Text = "2:  Low:"
        '
        'AnalogInput1WarningsLowLabel
        '
        Me.AnalogInput1WarningsLowLabel.AutoSize = True
        Me.AnalogInput1WarningsLowLabel.Location = New System.Drawing.Point(7, 18)
        Me.AnalogInput1WarningsLowLabel.Name = "AnalogInput1WarningsLowLabel"
        Me.AnalogInput1WarningsLowLabel.Size = New System.Drawing.Size(45, 13)
        Me.AnalogInput1WarningsLowLabel.TabIndex = 29
        Me.AnalogInput1WarningsLowLabel.Text = "1:  Low:"
        '
        'SettingsTabControl
        '
        Me.SettingsTabControl.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.SettingsTabControl.Controls.Add(Me.CameraPanAndTiltTabPage)
        Me.SettingsTabControl.Controls.Add(Me.InputsOutputsTabPage)
        Me.SettingsTabControl.Controls.Add(Me.MotorTabPage)
        Me.SettingsTabControl.Controls.Add(Me.CameraPresetTabPage)
        Me.SettingsTabControl.Controls.Add(Me.CommunicationTabPage)
        Me.SettingsTabControl.Controls.Add(Me.ComunicationCametaTabPage)
        Me.SettingsTabControl.Controls.Add(Me.FunctionsTabPage)
        Me.SettingsTabControl.Location = New System.Drawing.Point(0, 0)
        Me.SettingsTabControl.Multiline = True
        Me.SettingsTabControl.Name = "SettingsTabControl"
        Me.SettingsTabControl.SelectedIndex = 0
        Me.SettingsTabControl.Size = New System.Drawing.Size(632, 268)
        Me.SettingsTabControl.TabIndex = 38
        '
        'CameraPanAndTiltTabPage
        '
        Me.CameraPanAndTiltTabPage.Controls.Add(Me.GroupBox1)
        Me.CameraPanAndTiltTabPage.Controls.Add(Me.CameraPanGroupBox)
        Me.CameraPanAndTiltTabPage.Controls.Add(Me.CameraTiltGroupBox)
        Me.CameraPanAndTiltTabPage.Location = New System.Drawing.Point(4, 22)
        Me.CameraPanAndTiltTabPage.Name = "CameraPanAndTiltTabPage"
        Me.CameraPanAndTiltTabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.CameraPanAndTiltTabPage.Size = New System.Drawing.Size(624, 242)
        Me.CameraPanAndTiltTabPage.TabIndex = 0
        Me.CameraPanAndTiltTabPage.Text = "Camera Pan && Tilt"
        Me.CameraPanAndTiltTabPage.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CheckBoxInvertTilt)
        Me.GroupBox1.Controls.Add(Me.CheckBoxInvertPan)
        Me.GroupBox1.Location = New System.Drawing.Point(314, 187)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(302, 40)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Additional Settings"
        '
        'CheckBoxInvertTilt
        '
        Me.CheckBoxInvertTilt.AutoSize = True
        Me.CheckBoxInvertTilt.Location = New System.Drawing.Point(220, 13)
        Me.CheckBoxInvertTilt.Name = "CheckBoxInvertTilt"
        Me.CheckBoxInvertTilt.Size = New System.Drawing.Size(70, 17)
        Me.CheckBoxInvertTilt.TabIndex = 1
        Me.CheckBoxInvertTilt.Text = "Invert Tilt"
        Me.CheckBoxInvertTilt.UseVisualStyleBackColor = True
        '
        'CheckBoxInvertPan
        '
        Me.CheckBoxInvertPan.AutoSize = True
        Me.CheckBoxInvertPan.Location = New System.Drawing.Point(133, 13)
        Me.CheckBoxInvertPan.Name = "CheckBoxInvertPan"
        Me.CheckBoxInvertPan.Size = New System.Drawing.Size(75, 17)
        Me.CheckBoxInvertPan.TabIndex = 0
        Me.CheckBoxInvertPan.Text = "Invert Pan"
        Me.CheckBoxInvertPan.UseVisualStyleBackColor = True
        '
        'InputsOutputsTabPage
        '
        Me.InputsOutputsTabPage.Controls.Add(Me.Label19)
        Me.InputsOutputsTabPage.Controls.Add(Me.GroupBoxUltrasonicSensor)
        Me.InputsOutputsTabPage.Controls.Add(Me.OutOfRangeWarningsGroupBox)
        Me.InputsOutputsTabPage.Controls.Add(Me.DigitalInputsGroupBox)
        Me.InputsOutputsTabPage.Controls.Add(Me.AnalogInputsGroupBox)
        Me.InputsOutputsTabPage.Controls.Add(Me.OutputsGroupBox)
        Me.InputsOutputsTabPage.Location = New System.Drawing.Point(4, 22)
        Me.InputsOutputsTabPage.Name = "InputsOutputsTabPage"
        Me.InputsOutputsTabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.InputsOutputsTabPage.Size = New System.Drawing.Size(624, 242)
        Me.InputsOutputsTabPage.TabIndex = 1
        Me.InputsOutputsTabPage.Text = "Inputs/Outputs"
        Me.InputsOutputsTabPage.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Tahoma", 7.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label19.Location = New System.Drawing.Point(314, 170)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(288, 38)
        Me.Label19.TabIndex = 39
        Me.Label19.Text = "*) Enabling additional inputs other than what the robot's custom controller board" & _
            " is set up for will likely cause communication errors and undesirable results."
        '
        'GroupBoxUltrasonicSensor
        '
        Me.GroupBoxUltrasonicSensor.Controls.Add(Me.RadioButtonSensorUnitMetric)
        Me.GroupBoxUltrasonicSensor.Controls.Add(Me.RadioButtonSensorUnitImperial)
        Me.GroupBoxUltrasonicSensor.Controls.Add(Me.LabelUltrasonicUnits)
        Me.GroupBoxUltrasonicSensor.Controls.Add(Me.TextBoxOffset)
        Me.GroupBoxUltrasonicSensor.Controls.Add(Me.LabelOffset)
        Me.GroupBoxUltrasonicSensor.Controls.Add(Me.TextBoxMultiplier)
        Me.GroupBoxUltrasonicSensor.Controls.Add(Me.LabelUSSMultiplier)
        Me.GroupBoxUltrasonicSensor.Location = New System.Drawing.Point(316, 102)
        Me.GroupBoxUltrasonicSensor.Name = "GroupBoxUltrasonicSensor"
        Me.GroupBoxUltrasonicSensor.Size = New System.Drawing.Size(302, 65)
        Me.GroupBoxUltrasonicSensor.TabIndex = 38
        Me.GroupBoxUltrasonicSensor.TabStop = False
        Me.GroupBoxUltrasonicSensor.Text = "Ultrasonic sensor"
        '
        'RadioButtonSensorUnitMetric
        '
        Me.RadioButtonSensorUnitMetric.AutoSize = True
        Me.RadioButtonSensorUnitMetric.Location = New System.Drawing.Point(131, 41)
        Me.RadioButtonSensorUnitMetric.Name = "RadioButtonSensorUnitMetric"
        Me.RadioButtonSensorUnitMetric.Size = New System.Drawing.Size(80, 17)
        Me.RadioButtonSensorUnitMetric.TabIndex = 7
        Me.RadioButtonSensorUnitMetric.TabStop = True
        Me.RadioButtonSensorUnitMetric.Text = "Centimeters"
        Me.RadioButtonSensorUnitMetric.UseVisualStyleBackColor = True
        '
        'RadioButtonSensorUnitImperial
        '
        Me.RadioButtonSensorUnitImperial.AutoSize = True
        Me.RadioButtonSensorUnitImperial.Location = New System.Drawing.Point(58, 41)
        Me.RadioButtonSensorUnitImperial.Name = "RadioButtonSensorUnitImperial"
        Me.RadioButtonSensorUnitImperial.Size = New System.Drawing.Size(57, 17)
        Me.RadioButtonSensorUnitImperial.TabIndex = 6
        Me.RadioButtonSensorUnitImperial.TabStop = True
        Me.RadioButtonSensorUnitImperial.Text = "Inches"
        Me.RadioButtonSensorUnitImperial.UseVisualStyleBackColor = True
        '
        'LabelUltrasonicUnits
        '
        Me.LabelUltrasonicUnits.AutoSize = True
        Me.LabelUltrasonicUnits.Location = New System.Drawing.Point(18, 42)
        Me.LabelUltrasonicUnits.Name = "LabelUltrasonicUnits"
        Me.LabelUltrasonicUnits.Size = New System.Drawing.Size(34, 13)
        Me.LabelUltrasonicUnits.TabIndex = 5
        Me.LabelUltrasonicUnits.Text = "Units:"
        '
        'TextBoxOffset
        '
        Me.TextBoxOffset.Location = New System.Drawing.Point(203, 15)
        Me.TextBoxOffset.Name = "TextBoxOffset"
        Me.TextBoxOffset.Size = New System.Drawing.Size(88, 20)
        Me.TextBoxOffset.TabIndex = 3
        Me.TextBoxOffset.Text = "0.00"
        '
        'LabelOffset
        '
        Me.LabelOffset.AutoSize = True
        Me.LabelOffset.Location = New System.Drawing.Point(163, 18)
        Me.LabelOffset.Name = "LabelOffset"
        Me.LabelOffset.Size = New System.Drawing.Size(38, 13)
        Me.LabelOffset.TabIndex = 2
        Me.LabelOffset.Text = "Offset:"
        '
        'TextBoxMultiplier
        '
        Me.TextBoxMultiplier.Location = New System.Drawing.Point(58, 15)
        Me.TextBoxMultiplier.Name = "TextBoxMultiplier"
        Me.TextBoxMultiplier.Size = New System.Drawing.Size(88, 20)
        Me.TextBoxMultiplier.TabIndex = 1
        Me.TextBoxMultiplier.Text = "0.00"
        '
        'LabelUSSMultiplier
        '
        Me.LabelUSSMultiplier.AutoSize = True
        Me.LabelUSSMultiplier.Location = New System.Drawing.Point(7, 18)
        Me.LabelUSSMultiplier.Name = "LabelUSSMultiplier"
        Me.LabelUSSMultiplier.Size = New System.Drawing.Size(51, 13)
        Me.LabelUSSMultiplier.TabIndex = 0
        Me.LabelUSSMultiplier.Text = "Multiplier:"
        '
        'MotorTabPage
        '
        Me.MotorTabPage.Controls.Add(Me.DriveControlSettingsGroupBox)
        Me.MotorTabPage.Controls.Add(Me.EncoderCalibrationGroupBox)
        Me.MotorTabPage.Location = New System.Drawing.Point(4, 22)
        Me.MotorTabPage.Name = "MotorTabPage"
        Me.MotorTabPage.Size = New System.Drawing.Size(624, 242)
        Me.MotorTabPage.TabIndex = 2
        Me.MotorTabPage.Text = "Motor"
        Me.MotorTabPage.UseVisualStyleBackColor = True
        '
        'DriveControlSettingsGroupBox
        '
        Me.DriveControlSettingsGroupBox.Controls.Add(Me.chbDisableMotorMixing)
        Me.DriveControlSettingsGroupBox.Controls.Add(Me.UseReverseBitCheckBox)
        Me.DriveControlSettingsGroupBox.Controls.Add(Me.MotorOffTextBox)
        Me.DriveControlSettingsGroupBox.Controls.Add(Me.MotorOffLabel)
        Me.DriveControlSettingsGroupBox.Controls.Add(Me.MotorReverseFastLabel)
        Me.DriveControlSettingsGroupBox.Controls.Add(Me.MotorReverseFastTextBox)
        Me.DriveControlSettingsGroupBox.Controls.Add(Me.MotorReverseSlowTextBox)
        Me.DriveControlSettingsGroupBox.Controls.Add(Me.MotoroForwardFastTextBox)
        Me.DriveControlSettingsGroupBox.Controls.Add(Me.MotorForwardFastLabel)
        Me.DriveControlSettingsGroupBox.Controls.Add(Me.MotorForwardSlowTextBox)
        Me.DriveControlSettingsGroupBox.Controls.Add(Me.MotorReverseSlowLabel)
        Me.DriveControlSettingsGroupBox.Controls.Add(Me.MotorForwardSlowLabel)
        Me.DriveControlSettingsGroupBox.Location = New System.Drawing.Point(8, 112)
        Me.DriveControlSettingsGroupBox.Name = "DriveControlSettingsGroupBox"
        Me.DriveControlSettingsGroupBox.Size = New System.Drawing.Size(302, 123)
        Me.DriveControlSettingsGroupBox.TabIndex = 33
        Me.DriveControlSettingsGroupBox.TabStop = False
        Me.DriveControlSettingsGroupBox.Text = "Drive Control"
        '
        'chbDisableMotorMixing
        '
        Me.chbDisableMotorMixing.AutoSize = True
        Me.chbDisableMotorMixing.Location = New System.Drawing.Point(176, 95)
        Me.chbDisableMotorMixing.Name = "chbDisableMotorMixing"
        Me.chbDisableMotorMixing.Size = New System.Drawing.Size(122, 17)
        Me.chbDisableMotorMixing.TabIndex = 37
        Me.chbDisableMotorMixing.Text = "Disable motor mixing"
        Me.chbDisableMotorMixing.UseVisualStyleBackColor = True
        '
        'UseReverseBitCheckBox
        '
        Me.UseReverseBitCheckBox.AutoSize = True
        Me.UseReverseBitCheckBox.Location = New System.Drawing.Point(176, 72)
        Me.UseReverseBitCheckBox.Name = "UseReverseBitCheckBox"
        Me.UseReverseBitCheckBox.Size = New System.Drawing.Size(103, 17)
        Me.UseReverseBitCheckBox.TabIndex = 35
        Me.UseReverseBitCheckBox.Text = "Use Reverse Bit"
        Me.UseReverseBitCheckBox.UseVisualStyleBackColor = True
        '
        'MotorOffTextBox
        '
        Me.MotorOffTextBox.Location = New System.Drawing.Point(103, 70)
        Me.MotorOffTextBox.Name = "MotorOffTextBox"
        Me.MotorOffTextBox.Size = New System.Drawing.Size(53, 20)
        Me.MotorOffTextBox.TabIndex = 10
        '
        'MotorOffLabel
        '
        Me.MotorOffLabel.AutoSize = True
        Me.MotorOffLabel.Location = New System.Drawing.Point(42, 73)
        Me.MotorOffLabel.Name = "MotorOffLabel"
        Me.MotorOffLabel.Size = New System.Drawing.Size(54, 13)
        Me.MotorOffLabel.TabIndex = 9
        Me.MotorOffLabel.Text = "Motor Off:"
        '
        'MotorReverseFastLabel
        '
        Me.MotorReverseFastLabel.AutoSize = True
        Me.MotorReverseFastLabel.Location = New System.Drawing.Point(173, 47)
        Me.MotorReverseFastLabel.Name = "MotorReverseFastLabel"
        Me.MotorReverseFastLabel.Size = New System.Drawing.Size(30, 13)
        Me.MotorReverseFastLabel.TabIndex = 8
        Me.MotorReverseFastLabel.Text = "Fast:"
        '
        'MotorReverseFastTextBox
        '
        Me.MotorReverseFastTextBox.Location = New System.Drawing.Point(209, 44)
        Me.MotorReverseFastTextBox.Name = "MotorReverseFastTextBox"
        Me.MotorReverseFastTextBox.Size = New System.Drawing.Size(53, 20)
        Me.MotorReverseFastTextBox.TabIndex = 7
        '
        'MotorReverseSlowTextBox
        '
        Me.MotorReverseSlowTextBox.Location = New System.Drawing.Point(103, 44)
        Me.MotorReverseSlowTextBox.Name = "MotorReverseSlowTextBox"
        Me.MotorReverseSlowTextBox.Size = New System.Drawing.Size(53, 20)
        Me.MotorReverseSlowTextBox.TabIndex = 6
        '
        'MotoroForwardFastTextBox
        '
        Me.MotoroForwardFastTextBox.Location = New System.Drawing.Point(209, 18)
        Me.MotoroForwardFastTextBox.Name = "MotoroForwardFastTextBox"
        Me.MotoroForwardFastTextBox.Size = New System.Drawing.Size(53, 20)
        Me.MotoroForwardFastTextBox.TabIndex = 5
        '
        'MotorForwardFastLabel
        '
        Me.MotorForwardFastLabel.AutoSize = True
        Me.MotorForwardFastLabel.Location = New System.Drawing.Point(173, 21)
        Me.MotorForwardFastLabel.Name = "MotorForwardFastLabel"
        Me.MotorForwardFastLabel.Size = New System.Drawing.Size(30, 13)
        Me.MotorForwardFastLabel.TabIndex = 4
        Me.MotorForwardFastLabel.Text = "Fast:"
        '
        'MotorForwardSlowTextBox
        '
        Me.MotorForwardSlowTextBox.Location = New System.Drawing.Point(103, 18)
        Me.MotorForwardSlowTextBox.Name = "MotorForwardSlowTextBox"
        Me.MotorForwardSlowTextBox.Size = New System.Drawing.Size(53, 20)
        Me.MotorForwardSlowTextBox.TabIndex = 3
        '
        'MotorReverseSlowLabel
        '
        Me.MotorReverseSlowLabel.AutoSize = True
        Me.MotorReverseSlowLabel.Location = New System.Drawing.Point(20, 47)
        Me.MotorReverseSlowLabel.Name = "MotorReverseSlowLabel"
        Me.MotorReverseSlowLabel.Size = New System.Drawing.Size(76, 13)
        Me.MotorReverseSlowLabel.TabIndex = 1
        Me.MotorReverseSlowLabel.Text = "Reverse Slow:"
        '
        'MotorForwardSlowLabel
        '
        Me.MotorForwardSlowLabel.AutoSize = True
        Me.MotorForwardSlowLabel.Location = New System.Drawing.Point(22, 21)
        Me.MotorForwardSlowLabel.Name = "MotorForwardSlowLabel"
        Me.MotorForwardSlowLabel.Size = New System.Drawing.Size(74, 13)
        Me.MotorForwardSlowLabel.TabIndex = 0
        Me.MotorForwardSlowLabel.Text = "Forward Slow:"
        '
        'CameraPresetTabPage
        '
        Me.CameraPresetTabPage.Controls.Add(Me.grbPreset4)
        Me.CameraPresetTabPage.Controls.Add(Me.grbPreset3)
        Me.CameraPresetTabPage.Controls.Add(Me.grbPreset2)
        Me.CameraPresetTabPage.Controls.Add(Me.grbPreset1)
        Me.CameraPresetTabPage.Controls.Add(Me.tbtPresetInfo)
        Me.CameraPresetTabPage.Location = New System.Drawing.Point(4, 22)
        Me.CameraPresetTabPage.Name = "CameraPresetTabPage"
        Me.CameraPresetTabPage.Size = New System.Drawing.Size(624, 242)
        Me.CameraPresetTabPage.TabIndex = 4
        Me.CameraPresetTabPage.Text = "Camera presets"
        Me.CameraPresetTabPage.UseVisualStyleBackColor = True
        '
        'grbPreset4
        '
        Me.grbPreset4.Controls.Add(Me.Label51)
        Me.grbPreset4.Controls.Add(Me.Label52)
        Me.grbPreset4.Controls.Add(Me.txtCameraPreset4Tilt)
        Me.grbPreset4.Controls.Add(Me.txtCameraPreset4Pan)
        Me.grbPreset4.Controls.Add(Me.Label53)
        Me.grbPreset4.Controls.Add(Me.Label54)
        Me.grbPreset4.Location = New System.Drawing.Point(311, 72)
        Me.grbPreset4.Name = "grbPreset4"
        Me.grbPreset4.Size = New System.Drawing.Size(297, 63)
        Me.grbPreset4.TabIndex = 44
        Me.grbPreset4.TabStop = False
        Me.grbPreset4.Text = "Camera preset 4"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(183, 38)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(59, 13)
        Me.Label51.TabIndex = 20
        Me.Label51.Text = "Increments"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(183, 16)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(59, 13)
        Me.Label52.TabIndex = 19
        Me.Label52.Text = "Increments"
        '
        'txtCameraPreset4Tilt
        '
        Me.txtCameraPreset4Tilt.Location = New System.Drawing.Point(77, 35)
        Me.txtCameraPreset4Tilt.Name = "txtCameraPreset4Tilt"
        Me.txtCameraPreset4Tilt.Size = New System.Drawing.Size(100, 20)
        Me.txtCameraPreset4Tilt.TabIndex = 3
        Me.txtCameraPreset4Tilt.Text = "---"
        '
        'txtCameraPreset4Pan
        '
        Me.txtCameraPreset4Pan.Location = New System.Drawing.Point(77, 13)
        Me.txtCameraPreset4Pan.Name = "txtCameraPreset4Pan"
        Me.txtCameraPreset4Pan.Size = New System.Drawing.Size(100, 20)
        Me.txtCameraPreset4Pan.TabIndex = 2
        Me.txtCameraPreset4Pan.Text = "---"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(6, 38)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(60, 13)
        Me.Label53.TabIndex = 1
        Me.Label53.Text = "Tilt position"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(6, 16)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(65, 13)
        Me.Label54.TabIndex = 0
        Me.Label54.Text = "Pan position"
        '
        'grbPreset3
        '
        Me.grbPreset3.Controls.Add(Me.Label47)
        Me.grbPreset3.Controls.Add(Me.Label48)
        Me.grbPreset3.Controls.Add(Me.txtCameraPreset3Tilt)
        Me.grbPreset3.Controls.Add(Me.txtCameraPreset3Pan)
        Me.grbPreset3.Controls.Add(Me.Label49)
        Me.grbPreset3.Controls.Add(Me.Label50)
        Me.grbPreset3.Location = New System.Drawing.Point(311, 3)
        Me.grbPreset3.Name = "grbPreset3"
        Me.grbPreset3.Size = New System.Drawing.Size(297, 63)
        Me.grbPreset3.TabIndex = 43
        Me.grbPreset3.TabStop = False
        Me.grbPreset3.Text = "Camera preset 3"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(183, 38)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(59, 13)
        Me.Label47.TabIndex = 20
        Me.Label47.Text = "Increments"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(183, 16)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(59, 13)
        Me.Label48.TabIndex = 19
        Me.Label48.Text = "Increments"
        '
        'txtCameraPreset3Tilt
        '
        Me.txtCameraPreset3Tilt.Location = New System.Drawing.Point(77, 35)
        Me.txtCameraPreset3Tilt.Name = "txtCameraPreset3Tilt"
        Me.txtCameraPreset3Tilt.Size = New System.Drawing.Size(100, 20)
        Me.txtCameraPreset3Tilt.TabIndex = 3
        Me.txtCameraPreset3Tilt.Text = "---"
        '
        'txtCameraPreset3Pan
        '
        Me.txtCameraPreset3Pan.Location = New System.Drawing.Point(77, 13)
        Me.txtCameraPreset3Pan.Name = "txtCameraPreset3Pan"
        Me.txtCameraPreset3Pan.Size = New System.Drawing.Size(100, 20)
        Me.txtCameraPreset3Pan.TabIndex = 2
        Me.txtCameraPreset3Pan.Text = "---"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(6, 38)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(60, 13)
        Me.Label49.TabIndex = 1
        Me.Label49.Text = "Tilt position"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(6, 16)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(65, 13)
        Me.Label50.TabIndex = 0
        Me.Label50.Text = "Pan position"
        '
        'grbPreset2
        '
        Me.grbPreset2.Controls.Add(Me.Label43)
        Me.grbPreset2.Controls.Add(Me.Label44)
        Me.grbPreset2.Controls.Add(Me.txtCameraPreset2Tilt)
        Me.grbPreset2.Controls.Add(Me.txtCameraPreset2Pan)
        Me.grbPreset2.Controls.Add(Me.Label45)
        Me.grbPreset2.Controls.Add(Me.Label46)
        Me.grbPreset2.Location = New System.Drawing.Point(8, 72)
        Me.grbPreset2.Name = "grbPreset2"
        Me.grbPreset2.Size = New System.Drawing.Size(297, 63)
        Me.grbPreset2.TabIndex = 42
        Me.grbPreset2.TabStop = False
        Me.grbPreset2.Text = "Camera preset 2"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(183, 38)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(59, 13)
        Me.Label43.TabIndex = 20
        Me.Label43.Text = "Increments"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(183, 16)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(59, 13)
        Me.Label44.TabIndex = 19
        Me.Label44.Text = "Increments"
        '
        'txtCameraPreset2Tilt
        '
        Me.txtCameraPreset2Tilt.Location = New System.Drawing.Point(77, 35)
        Me.txtCameraPreset2Tilt.Name = "txtCameraPreset2Tilt"
        Me.txtCameraPreset2Tilt.Size = New System.Drawing.Size(100, 20)
        Me.txtCameraPreset2Tilt.TabIndex = 3
        Me.txtCameraPreset2Tilt.Text = "---"
        '
        'txtCameraPreset2Pan
        '
        Me.txtCameraPreset2Pan.Location = New System.Drawing.Point(77, 13)
        Me.txtCameraPreset2Pan.Name = "txtCameraPreset2Pan"
        Me.txtCameraPreset2Pan.Size = New System.Drawing.Size(100, 20)
        Me.txtCameraPreset2Pan.TabIndex = 2
        Me.txtCameraPreset2Pan.Text = "---"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(6, 38)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(60, 13)
        Me.Label45.TabIndex = 1
        Me.Label45.Text = "Tilt position"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(6, 16)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(65, 13)
        Me.Label46.TabIndex = 0
        Me.Label46.Text = "Pan position"
        '
        'grbPreset1
        '
        Me.grbPreset1.Controls.Add(Me.Label42)
        Me.grbPreset1.Controls.Add(Me.Label41)
        Me.grbPreset1.Controls.Add(Me.txtCameraPreset1Tilt)
        Me.grbPreset1.Controls.Add(Me.txtCameraPreset1Pan)
        Me.grbPreset1.Controls.Add(Me.Label40)
        Me.grbPreset1.Controls.Add(Me.Label39)
        Me.grbPreset1.Location = New System.Drawing.Point(8, 3)
        Me.grbPreset1.Name = "grbPreset1"
        Me.grbPreset1.Size = New System.Drawing.Size(297, 63)
        Me.grbPreset1.TabIndex = 41
        Me.grbPreset1.TabStop = False
        Me.grbPreset1.Text = "Camera preset 1"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(183, 38)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(59, 13)
        Me.Label42.TabIndex = 20
        Me.Label42.Text = "Increments"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(183, 16)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(59, 13)
        Me.Label41.TabIndex = 19
        Me.Label41.Text = "Increments"
        '
        'txtCameraPreset1Tilt
        '
        Me.txtCameraPreset1Tilt.Location = New System.Drawing.Point(77, 35)
        Me.txtCameraPreset1Tilt.Name = "txtCameraPreset1Tilt"
        Me.txtCameraPreset1Tilt.Size = New System.Drawing.Size(100, 20)
        Me.txtCameraPreset1Tilt.TabIndex = 3
        Me.txtCameraPreset1Tilt.Text = "---"
        '
        'txtCameraPreset1Pan
        '
        Me.txtCameraPreset1Pan.Location = New System.Drawing.Point(77, 13)
        Me.txtCameraPreset1Pan.Name = "txtCameraPreset1Pan"
        Me.txtCameraPreset1Pan.Size = New System.Drawing.Size(100, 20)
        Me.txtCameraPreset1Pan.TabIndex = 2
        Me.txtCameraPreset1Pan.Text = "---"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(6, 38)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(60, 13)
        Me.Label40.TabIndex = 1
        Me.Label40.Text = "Tilt position"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(6, 16)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(65, 13)
        Me.Label39.TabIndex = 0
        Me.Label39.Text = "Pan position"
        '
        'tbtPresetInfo
        '
        Me.tbtPresetInfo.Font = New System.Drawing.Font("Tahoma", 7.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.tbtPresetInfo.Location = New System.Drawing.Point(6, 138)
        Me.tbtPresetInfo.Name = "tbtPresetInfo"
        Me.tbtPresetInfo.Size = New System.Drawing.Size(299, 16)
        Me.tbtPresetInfo.TabIndex = 40
        Me.tbtPresetInfo.Text = "*) To use presset hold button 7 and  then press button 1,2,3 or 4."
        '
        'CommunicationTabPage
        '
        Me.CommunicationTabPage.Controls.Add(Me.CameraDeviceGroupBox)
        Me.CommunicationTabPage.Controls.Add(Me.CameraConnectionGroupBox)
        Me.CommunicationTabPage.Controls.Add(Me.CommunicationGroupBox)
        Me.CommunicationTabPage.Controls.Add(Me.TimersGroupBox)
        Me.CommunicationTabPage.Location = New System.Drawing.Point(4, 22)
        Me.CommunicationTabPage.Name = "CommunicationTabPage"
        Me.CommunicationTabPage.Size = New System.Drawing.Size(624, 242)
        Me.CommunicationTabPage.TabIndex = 3
        Me.CommunicationTabPage.Text = "Communication"
        Me.CommunicationTabPage.UseVisualStyleBackColor = True
        '
        'CameraDeviceGroupBox
        '
        Me.CameraDeviceGroupBox.Controls.Add(Me.RadioButtonRunAsClient)
        Me.CameraDeviceGroupBox.Controls.Add(Me.RadioButtonRunAsServer)
        Me.CameraDeviceGroupBox.Location = New System.Drawing.Point(316, 6)
        Me.CameraDeviceGroupBox.Name = "CameraDeviceGroupBox"
        Me.CameraDeviceGroupBox.Size = New System.Drawing.Size(302, 42)
        Me.CameraDeviceGroupBox.TabIndex = 16
        Me.CameraDeviceGroupBox.TabStop = False
        Me.CameraDeviceGroupBox.Text = "Run As"
        '
        'RadioButtonRunAsClient
        '
        Me.RadioButtonRunAsClient.AutoSize = True
        Me.RadioButtonRunAsClient.Location = New System.Drawing.Point(169, 16)
        Me.RadioButtonRunAsClient.Name = "RadioButtonRunAsClient"
        Me.RadioButtonRunAsClient.Size = New System.Drawing.Size(97, 17)
        Me.RadioButtonRunAsClient.TabIndex = 1
        Me.RadioButtonRunAsClient.Text = "Client (Remote)"
        Me.RadioButtonRunAsClient.UseVisualStyleBackColor = True
        '
        'RadioButtonRunAsServer
        '
        Me.RadioButtonRunAsServer.AutoSize = True
        Me.RadioButtonRunAsServer.Checked = True
        Me.RadioButtonRunAsServer.Location = New System.Drawing.Point(29, 16)
        Me.RadioButtonRunAsServer.Name = "RadioButtonRunAsServer"
        Me.RadioButtonRunAsServer.Size = New System.Drawing.Size(94, 17)
        Me.RadioButtonRunAsServer.TabIndex = 0
        Me.RadioButtonRunAsServer.TabStop = True
        Me.RadioButtonRunAsServer.Text = "Server (Robot)"
        Me.RadioButtonRunAsServer.UseVisualStyleBackColor = True
        '
        'CameraConnectionGroupBox
        '
        Me.CameraConnectionGroupBox.Controls.Add(Me.cbEnableRemoteControllingAfterStartup)
        Me.CameraConnectionGroupBox.Controls.Add(Me.CameraPasswordTextBox)
        Me.CameraConnectionGroupBox.Controls.Add(Me.CameraPasswordLabel)
        Me.CameraConnectionGroupBox.Controls.Add(Me.CameraLoginTextBox)
        Me.CameraConnectionGroupBox.Controls.Add(Me.CameraLoginLabel)
        Me.CameraConnectionGroupBox.Controls.Add(Me.CameraPortTextBox)
        Me.CameraConnectionGroupBox.Controls.Add(Me.CameraPortLabel)
        Me.CameraConnectionGroupBox.Controls.Add(Me.CameraIPAddressTextBox)
        Me.CameraConnectionGroupBox.Controls.Add(Me.CameraIPLabel)
        Me.CameraConnectionGroupBox.Location = New System.Drawing.Point(316, 54)
        Me.CameraConnectionGroupBox.Name = "CameraConnectionGroupBox"
        Me.CameraConnectionGroupBox.Size = New System.Drawing.Size(302, 69)
        Me.CameraConnectionGroupBox.TabIndex = 15
        Me.CameraConnectionGroupBox.TabStop = False
        Me.CameraConnectionGroupBox.Text = "Remote Control Connection"
        '
        'cbEnableRemoteControllingAfterStartup
        '
        Me.cbEnableRemoteControllingAfterStartup.AutoSize = True
        Me.cbEnableRemoteControllingAfterStartup.Location = New System.Drawing.Point(78, 42)
        Me.cbEnableRemoteControllingAfterStartup.Name = "cbEnableRemoteControllingAfterStartup"
        Me.cbEnableRemoteControllingAfterStartup.Size = New System.Drawing.Size(210, 17)
        Me.cbEnableRemoteControllingAfterStartup.TabIndex = 30
        Me.cbEnableRemoteControllingAfterStartup.Text = "Enable Remote Controlling after startup" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.cbEnableRemoteControllingAfterStartup.UseVisualStyleBackColor = True
        '
        'CameraPasswordLabel
        '
        Me.CameraPasswordLabel.AutoSize = True
        Me.CameraPasswordLabel.Location = New System.Drawing.Point(3, 43)
        Me.CameraPasswordLabel.Name = "CameraPasswordLabel"
        Me.CameraPasswordLabel.Size = New System.Drawing.Size(56, 13)
        Me.CameraPasswordLabel.TabIndex = 29
        Me.CameraPasswordLabel.Text = "Password:"
        Me.CameraPasswordLabel.Visible = False
        '
        'CameraLoginLabel
        '
        Me.CameraLoginLabel.AutoSize = True
        Me.CameraLoginLabel.Location = New System.Drawing.Point(20, 43)
        Me.CameraLoginLabel.Name = "CameraLoginLabel"
        Me.CameraLoginLabel.Size = New System.Drawing.Size(36, 13)
        Me.CameraLoginLabel.TabIndex = 26
        Me.CameraLoginLabel.Text = "Login:"
        Me.CameraLoginLabel.Visible = False
        '
        'CameraPortLabel
        '
        Me.CameraPortLabel.AutoSize = True
        Me.CameraPortLabel.Location = New System.Drawing.Point(193, 20)
        Me.CameraPortLabel.Name = "CameraPortLabel"
        Me.CameraPortLabel.Size = New System.Drawing.Size(29, 13)
        Me.CameraPortLabel.TabIndex = 23
        Me.CameraPortLabel.Text = "Port:"
        '
        'CameraIPLabel
        '
        Me.CameraIPLabel.AutoSize = True
        Me.CameraIPLabel.Location = New System.Drawing.Point(11, 20)
        Me.CameraIPLabel.Name = "CameraIPLabel"
        Me.CameraIPLabel.Size = New System.Drawing.Size(61, 13)
        Me.CameraIPLabel.TabIndex = 20
        Me.CameraIPLabel.Text = "IP Address:"
        '
        'ComunicationCametaTabPage
        '
        Me.ComunicationCametaTabPage.Controls.Add(Me.AudioGroupBox)
        Me.ComunicationCametaTabPage.Controls.Add(Me.UsbCameraEncodingGroupBox)
        Me.ComunicationCametaTabPage.Controls.Add(Me.UsbCameraConnectionGroupBox)
        Me.ComunicationCametaTabPage.Location = New System.Drawing.Point(4, 22)
        Me.ComunicationCametaTabPage.Name = "ComunicationCametaTabPage"
        Me.ComunicationCametaTabPage.Size = New System.Drawing.Size(624, 242)
        Me.ComunicationCametaTabPage.TabIndex = 6
        Me.ComunicationCametaTabPage.Text = "Camera & audio settings "
        Me.ComunicationCametaTabPage.UseVisualStyleBackColor = True
        '
        'AudioGroupBox
        '
        Me.AudioGroupBox.Controls.Add(Me.cmbAudioOutput)
        Me.AudioGroupBox.Controls.Add(Me.lblAudioOutput)
        Me.AudioGroupBox.Controls.Add(Me.cmbAudioInput)
        Me.AudioGroupBox.Controls.Add(Me.lblAudioInput)
        Me.AudioGroupBox.Location = New System.Drawing.Point(8, 164)
        Me.AudioGroupBox.Name = "AudioGroupBox"
        Me.AudioGroupBox.Size = New System.Drawing.Size(302, 74)
        Me.AudioGroupBox.TabIndex = 33
        Me.AudioGroupBox.TabStop = False
        Me.AudioGroupBox.Text = "Audio settings"
        '
        'cmbAudioOutput
        '
        Me.cmbAudioOutput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbAudioOutput.FormattingEnabled = True
        Me.cmbAudioOutput.Location = New System.Drawing.Point(90, 42)
        Me.cmbAudioOutput.Name = "cmbAudioOutput"
        Me.cmbAudioOutput.Size = New System.Drawing.Size(200, 21)
        Me.cmbAudioOutput.TabIndex = 26
        '
        'lblAudioOutput
        '
        Me.lblAudioOutput.AutoSize = True
        Me.lblAudioOutput.Location = New System.Drawing.Point(11, 45)
        Me.lblAudioOutput.Name = "lblAudioOutput"
        Me.lblAudioOutput.Size = New System.Drawing.Size(70, 13)
        Me.lblAudioOutput.TabIndex = 25
        Me.lblAudioOutput.Text = "Audio output:"
        '
        'cmbAudioInput
        '
        Me.cmbAudioInput.DisplayMember = "Text"
        Me.cmbAudioInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbAudioInput.FormattingEnabled = True
        Me.cmbAudioInput.Location = New System.Drawing.Point(90, 19)
        Me.cmbAudioInput.Name = "cmbAudioInput"
        Me.cmbAudioInput.Size = New System.Drawing.Size(200, 21)
        Me.cmbAudioInput.TabIndex = 24
        Me.cmbAudioInput.ValueMember = "Value"
        '
        'lblAudioInput
        '
        Me.lblAudioInput.AutoSize = True
        Me.lblAudioInput.Location = New System.Drawing.Point(10, 22)
        Me.lblAudioInput.Name = "lblAudioInput"
        Me.lblAudioInput.Size = New System.Drawing.Size(63, 13)
        Me.lblAudioInput.TabIndex = 20
        Me.lblAudioInput.Text = "Audio input:"
        '
        'UsbCameraEncodingGroupBox
        '
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.lblCodecInfo)
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.lblVideoH264Profile)
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.lblVideoH264SpeedLevel)
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.cmbVideoH264Profile)
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.cmbVideoH264SpeedLevel)
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.txtVideoFrameRate)
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.lblVideoFrameRate)
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.lblVideoFrameCaptureInterval)
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.txtVideoFrameCaptureInterval)
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.txtVideoIFrameFrequency)
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.txtVideoBitRate)
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.lblVideoBitRate)
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.lblIFrameFrequency)
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.cmbVideoEncodingResolution)
        Me.UsbCameraEncodingGroupBox.Controls.Add(Me.lblVideoEncodingResolution)
        Me.UsbCameraEncodingGroupBox.Location = New System.Drawing.Point(316, 3)
        Me.UsbCameraEncodingGroupBox.Name = "UsbCameraEncodingGroupBox"
        Me.UsbCameraEncodingGroupBox.Size = New System.Drawing.Size(302, 235)
        Me.UsbCameraEncodingGroupBox.TabIndex = 32
        Me.UsbCameraEncodingGroupBox.TabStop = False
        Me.UsbCameraEncodingGroupBox.Text = "USB Camera encoding (codec H264)"
        '
        'lblCodecInfo
        '
        Me.lblCodecInfo.AutoSize = True
        Me.lblCodecInfo.Location = New System.Drawing.Point(58, 211)
        Me.lblCodecInfo.Name = "lblCodecInfo"
        Me.lblCodecInfo.Size = New System.Drawing.Size(232, 13)
        Me.lblCodecInfo.TabIndex = 41
        Me.lblCodecInfo.Text = "Codec info : http://en.wikipedia.org/wiki/H.264"
        '
        'lblVideoH264Profile
        '
        Me.lblVideoH264Profile.AutoSize = True
        Me.lblVideoH264Profile.Location = New System.Drawing.Point(11, 76)
        Me.lblVideoH264Profile.Name = "lblVideoH264Profile"
        Me.lblVideoH264Profile.Size = New System.Drawing.Size(39, 13)
        Me.lblVideoH264Profile.TabIndex = 40
        Me.lblVideoH264Profile.Text = "Profile:"
        '
        'lblVideoH264SpeedLevel
        '
        Me.lblVideoH264SpeedLevel.AutoSize = True
        Me.lblVideoH264SpeedLevel.Location = New System.Drawing.Point(11, 49)
        Me.lblVideoH264SpeedLevel.Name = "lblVideoH264SpeedLevel"
        Me.lblVideoH264SpeedLevel.Size = New System.Drawing.Size(66, 13)
        Me.lblVideoH264SpeedLevel.TabIndex = 39
        Me.lblVideoH264SpeedLevel.Text = "Speed level:"
        '
        'lblVideoFrameRate
        '
        Me.lblVideoFrameRate.AutoSize = True
        Me.lblVideoFrameRate.Location = New System.Drawing.Point(11, 104)
        Me.lblVideoFrameRate.Name = "lblVideoFrameRate"
        Me.lblVideoFrameRate.Size = New System.Drawing.Size(60, 13)
        Me.lblVideoFrameRate.TabIndex = 35
        Me.lblVideoFrameRate.Text = "Frame rate:"
        '
        'lblVideoFrameCaptureInterval
        '
        Me.lblVideoFrameCaptureInterval.AutoSize = True
        Me.lblVideoFrameCaptureInterval.Location = New System.Drawing.Point(11, 183)
        Me.lblVideoFrameCaptureInterval.Name = "lblVideoFrameCaptureInterval"
        Me.lblVideoFrameCaptureInterval.Size = New System.Drawing.Size(112, 13)
        Me.lblVideoFrameCaptureInterval.TabIndex = 34
        Me.lblVideoFrameCaptureInterval.Text = "Frame capture interval"
        '
        'lblVideoBitRate
        '
        Me.lblVideoBitRate.AutoSize = True
        Me.lblVideoBitRate.Location = New System.Drawing.Point(11, 130)
        Me.lblVideoBitRate.Name = "lblVideoBitRate"
        Me.lblVideoBitRate.Size = New System.Drawing.Size(43, 13)
        Me.lblVideoBitRate.TabIndex = 29
        Me.lblVideoBitRate.Text = "Bit rate:"
        '
        'lblIFrameFrequency
        '
        Me.lblIFrameFrequency.AutoSize = True
        Me.lblIFrameFrequency.Location = New System.Drawing.Point(11, 157)
        Me.lblIFrameFrequency.Name = "lblIFrameFrequency"
        Me.lblIFrameFrequency.Size = New System.Drawing.Size(95, 13)
        Me.lblIFrameFrequency.TabIndex = 30
        Me.lblIFrameFrequency.Text = "I-Frame frequency:"
        '
        'lblVideoEncodingResolution
        '
        Me.lblVideoEncodingResolution.AutoSize = True
        Me.lblVideoEncodingResolution.Location = New System.Drawing.Point(11, 22)
        Me.lblVideoEncodingResolution.Name = "lblVideoEncodingResolution"
        Me.lblVideoEncodingResolution.Size = New System.Drawing.Size(75, 13)
        Me.lblVideoEncodingResolution.TabIndex = 27
        Me.lblVideoEncodingResolution.Text = "Encoding res.:"
        '
        'UsbCameraConnectionGroupBox
        '
        Me.UsbCameraConnectionGroupBox.Controls.Add(Me.cmbVideoPreviewSize)
        Me.UsbCameraConnectionGroupBox.Controls.Add(Me.lblVideoPreviewSize)
        Me.UsbCameraConnectionGroupBox.Controls.Add(Me.UsbCamVideoDeviceComboBox)
        Me.UsbCameraConnectionGroupBox.Controls.Add(Me.UsbCamVideoDeviceLabel)
        Me.UsbCameraConnectionGroupBox.Location = New System.Drawing.Point(8, 3)
        Me.UsbCameraConnectionGroupBox.Name = "UsbCameraConnectionGroupBox"
        Me.UsbCameraConnectionGroupBox.Size = New System.Drawing.Size(302, 74)
        Me.UsbCameraConnectionGroupBox.TabIndex = 31
        Me.UsbCameraConnectionGroupBox.TabStop = False
        Me.UsbCameraConnectionGroupBox.Text = "USB Camera settings"
        '
        'cmbVideoPreviewSize
        '
        Me.cmbVideoPreviewSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbVideoPreviewSize.FormattingEnabled = True
        Me.cmbVideoPreviewSize.Location = New System.Drawing.Point(90, 42)
        Me.cmbVideoPreviewSize.Name = "cmbVideoPreviewSize"
        Me.cmbVideoPreviewSize.Size = New System.Drawing.Size(200, 21)
        Me.cmbVideoPreviewSize.TabIndex = 26
        '
        'lblVideoPreviewSize
        '
        Me.lblVideoPreviewSize.AutoSize = True
        Me.lblVideoPreviewSize.Location = New System.Drawing.Point(11, 45)
        Me.lblVideoPreviewSize.Name = "lblVideoPreviewSize"
        Me.lblVideoPreviewSize.Size = New System.Drawing.Size(69, 13)
        Me.lblVideoPreviewSize.TabIndex = 25
        Me.lblVideoPreviewSize.Text = "Preview size:"
        '
        'UsbCamVideoDeviceComboBox
        '
        Me.UsbCamVideoDeviceComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.UsbCamVideoDeviceComboBox.FormattingEnabled = True
        Me.UsbCamVideoDeviceComboBox.Location = New System.Drawing.Point(90, 19)
        Me.UsbCamVideoDeviceComboBox.Name = "UsbCamVideoDeviceComboBox"
        Me.UsbCamVideoDeviceComboBox.Size = New System.Drawing.Size(200, 21)
        Me.UsbCamVideoDeviceComboBox.TabIndex = 24
        '
        'UsbCamVideoDeviceLabel
        '
        Me.UsbCamVideoDeviceLabel.AutoSize = True
        Me.UsbCamVideoDeviceLabel.Location = New System.Drawing.Point(10, 22)
        Me.UsbCamVideoDeviceLabel.Name = "UsbCamVideoDeviceLabel"
        Me.UsbCamVideoDeviceLabel.Size = New System.Drawing.Size(74, 13)
        Me.UsbCamVideoDeviceLabel.TabIndex = 20
        Me.UsbCamVideoDeviceLabel.Text = "Video Device:"
        '
        'FunctionsTabPage
        '
        Me.FunctionsTabPage.Controls.Add(Me.chbDisableEncodersCount)
        Me.FunctionsTabPage.Controls.Add(Me.chbDisableZoom)
        Me.FunctionsTabPage.Controls.Add(Me.chbDisablePanTilt)
        Me.FunctionsTabPage.Controls.Add(Me.chbDisableBumperSwitch)
        Me.FunctionsTabPage.Controls.Add(Me.chbDisableSonar)
        Me.FunctionsTabPage.Controls.Add(Me.chbDisableEncoders)
        Me.FunctionsTabPage.Location = New System.Drawing.Point(4, 22)
        Me.FunctionsTabPage.Name = "FunctionsTabPage"
        Me.FunctionsTabPage.Size = New System.Drawing.Size(624, 242)
        Me.FunctionsTabPage.TabIndex = 5
        Me.FunctionsTabPage.Text = "Functions"
        Me.FunctionsTabPage.UseVisualStyleBackColor = True
        '
        'chbDisableZoom
        '
        Me.chbDisableZoom.AutoSize = True
        Me.chbDisableZoom.Location = New System.Drawing.Point(22, 128)
        Me.chbDisableZoom.Name = "chbDisableZoom"
        Me.chbDisableZoom.Size = New System.Drawing.Size(125, 17)
        Me.chbDisableZoom.TabIndex = 4
        Me.chbDisableZoom.Text = "Disable Zoom In/Out"
        Me.chbDisableZoom.UseVisualStyleBackColor = True
        '
        'chbDisablePanTilt
        '
        Me.chbDisablePanTilt.AutoSize = True
        Me.chbDisablePanTilt.Location = New System.Drawing.Point(22, 105)
        Me.chbDisablePanTilt.Name = "chbDisablePanTilt"
        Me.chbDisablePanTilt.Size = New System.Drawing.Size(148, 17)
        Me.chbDisablePanTilt.TabIndex = 3
        Me.chbDisablePanTilt.Text = "Disable Camera Pan && Tilt"
        Me.chbDisablePanTilt.UseVisualStyleBackColor = True
        '
        'chbDisableBumperSwitch
        '
        Me.chbDisableBumperSwitch.AutoSize = True
        Me.chbDisableBumperSwitch.Location = New System.Drawing.Point(22, 82)
        Me.chbDisableBumperSwitch.Name = "chbDisableBumperSwitch"
        Me.chbDisableBumperSwitch.Size = New System.Drawing.Size(133, 17)
        Me.chbDisableBumperSwitch.TabIndex = 2
        Me.chbDisableBumperSwitch.Text = "Disable Bumper switch"
        Me.chbDisableBumperSwitch.UseVisualStyleBackColor = True
        '
        'chbDisableSonar
        '
        Me.chbDisableSonar.AutoSize = True
        Me.chbDisableSonar.Location = New System.Drawing.Point(22, 59)
        Me.chbDisableSonar.Name = "chbDisableSonar"
        Me.chbDisableSonar.Size = New System.Drawing.Size(92, 17)
        Me.chbDisableSonar.TabIndex = 1
        Me.chbDisableSonar.Text = "Disable Sonar"
        Me.chbDisableSonar.UseVisualStyleBackColor = True
        '
        'chbDisableEncoders
        '
        Me.chbDisableEncoders.AutoSize = True
        Me.chbDisableEncoders.Location = New System.Drawing.Point(22, 13)
        Me.chbDisableEncoders.Name = "chbDisableEncoders"
        Me.chbDisableEncoders.Size = New System.Drawing.Size(109, 17)
        Me.chbDisableEncoders.TabIndex = 0
        Me.chbDisableEncoders.Text = "Disable Encoders"
        Me.chbDisableEncoders.UseVisualStyleBackColor = True
        '
        'chbDisableEncodersCount
        '
        Me.chbDisableEncodersCount.AutoSize = True
        Me.chbDisableEncodersCount.Location = New System.Drawing.Point(22, 36)
        Me.chbDisableEncodersCount.Name = "chbDisableEncodersCount"
        Me.chbDisableEncodersCount.Size = New System.Drawing.Size(140, 17)
        Me.chbDisableEncodersCount.TabIndex = 5
        Me.chbDisableEncodersCount.Text = "Disable Encoders Count"
        Me.chbDisableEncodersCount.UseVisualStyleBackColor = True
        '
        'SettingsForm
        '
        Me.AcceptButton = Me.updateAndCloseButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.cancelFormButton
        Me.ClientSize = New System.Drawing.Size(633, 320)
        Me.Controls.Add(Me.SettingsTabControl)
        Me.Controls.Add(Me.cancelFormButton)
        Me.Controls.Add(Me.updateAndCloseButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "SettingsForm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Settings"
        Me.CameraPanGroupBox.ResumeLayout(False)
        Me.CameraPanGroupBox.PerformLayout()
        Me.CameraTiltGroupBox.ResumeLayout(False)
        Me.CameraTiltGroupBox.PerformLayout()
        Me.TimersGroupBox.ResumeLayout(False)
        Me.TimersGroupBox.PerformLayout()
        Me.CommunicationGroupBox.ResumeLayout(False)
        Me.CommunicationGroupBox.PerformLayout()
        Me.EncoderCalibrationGroupBox.ResumeLayout(False)
        Me.EncoderCalibrationGroupBox.PerformLayout()
        Me.OutputsGroupBox.ResumeLayout(False)
        Me.OutputsGroupBox.PerformLayout()
        Me.AnalogInputsGroupBox.ResumeLayout(False)
        Me.AnalogInputsGroupBox.PerformLayout()
        Me.DigitalInputsGroupBox.ResumeLayout(False)
        Me.DigitalInputsGroupBox.PerformLayout()
        Me.OutOfRangeWarningsGroupBox.ResumeLayout(False)
        Me.OutOfRangeWarningsGroupBox.PerformLayout()
        Me.SettingsTabControl.ResumeLayout(False)
        Me.CameraPanAndTiltTabPage.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.InputsOutputsTabPage.ResumeLayout(False)
        Me.GroupBoxUltrasonicSensor.ResumeLayout(False)
        Me.GroupBoxUltrasonicSensor.PerformLayout()
        Me.MotorTabPage.ResumeLayout(False)
        Me.DriveControlSettingsGroupBox.ResumeLayout(False)
        Me.DriveControlSettingsGroupBox.PerformLayout()
        Me.CameraPresetTabPage.ResumeLayout(False)
        Me.grbPreset4.ResumeLayout(False)
        Me.grbPreset4.PerformLayout()
        Me.grbPreset3.ResumeLayout(False)
        Me.grbPreset3.PerformLayout()
        Me.grbPreset2.ResumeLayout(False)
        Me.grbPreset2.PerformLayout()
        Me.grbPreset1.ResumeLayout(False)
        Me.grbPreset1.PerformLayout()
        Me.CommunicationTabPage.ResumeLayout(False)
        Me.CameraDeviceGroupBox.ResumeLayout(False)
        Me.CameraDeviceGroupBox.PerformLayout()
        Me.CameraConnectionGroupBox.ResumeLayout(False)
        Me.CameraConnectionGroupBox.PerformLayout()
        Me.ComunicationCametaTabPage.ResumeLayout(False)
        Me.AudioGroupBox.ResumeLayout(False)
        Me.AudioGroupBox.PerformLayout()
        Me.UsbCameraEncodingGroupBox.ResumeLayout(False)
        Me.UsbCameraEncodingGroupBox.PerformLayout()
        Me.UsbCameraConnectionGroupBox.ResumeLayout(False)
        Me.UsbCameraConnectionGroupBox.PerformLayout()
        Me.FunctionsTabPage.ResumeLayout(False)
        Me.FunctionsTabPage.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CameraPanGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents CameraTiltGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents TimersGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents reversePanPosition2TextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents rightPanPositionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents forwardPanPositionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents leftPanPositionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents upPositionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents downPositionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents horizontalPositionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents txTimerIntervalTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents updateAndCloseButton As System.Windows.Forms.Button
    Friend WithEvents cancelFormButton As System.Windows.Forms.Button

    Friend WithEvents CommunicationGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents dataCOMComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents dataAutoCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents dataLabel As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents minPanPositionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents maxPanPositionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents panStepTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents tiltStepTextBox As System.Windows.Forms.TextBox
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents minTiltPositionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents maxTiltPositionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents tiltTimerIntervalTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents panTimerIntervalTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents EncoderCalibrationGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents OutputsGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents AnalogInputsGroupBox As System.Windows.Forms.GroupBox
    '<Obsolete("Use something else")> _
    <Restriction(RestrictionAttribute.Restriction.IsSingle)> _
    Friend WithEvents LeftEncoderCalibrationTextBox As System.Windows.Forms.TextBox
    Friend WithEvents lecCountInchLabel As System.Windows.Forms.Label
    Friend WithEvents LeftEncoderCalibrationLabel As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsSingle)> _
    Friend WithEvents RightEncoderCalibrationTextBox As System.Windows.Forms.TextBox
    Friend WithEvents recCountInchLabel As System.Windows.Forms.Label
    Friend WithEvents RightEncoderCalibrationLabel As System.Windows.Forms.Label
    Friend WithEvents Output4Label As System.Windows.Forms.Label
    Friend WithEvents Output3Label As System.Windows.Forms.Label
    Friend WithEvents Output2Label As System.Windows.Forms.Label
    Friend WithEvents Output1Label As System.Windows.Forms.Label
    Friend WithEvents Output4CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Output3CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Output2CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Output1CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Output4TextBox As System.Windows.Forms.TextBox
    Friend WithEvents Output3TextBox As System.Windows.Forms.TextBox
    Friend WithEvents Output2TextBox As System.Windows.Forms.TextBox
    Friend WithEvents Output1TextBox As System.Windows.Forms.TextBox
    Friend WithEvents DigitalInputsGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents DigitalInput4CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents DigitalInput3CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents DigitalInput2CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents DigitalInput1CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents DigitalInput4TextBox As System.Windows.Forms.TextBox
    Friend WithEvents DigitalInput3TextBox As System.Windows.Forms.TextBox
    Friend WithEvents DigitalInput2TextBox As System.Windows.Forms.TextBox
    Friend WithEvents DigitalInput1TextBox As System.Windows.Forms.TextBox
    Friend WithEvents DigitalInput4Label As System.Windows.Forms.Label
    Friend WithEvents DigitalInput3Label As System.Windows.Forms.Label
    Friend WithEvents DigitalInput2Label As System.Windows.Forms.Label
    Friend WithEvents DigitalInput1Label As System.Windows.Forms.Label
    Friend WithEvents AnalogInput3CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents AnalogInput2CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents AnalogInput1CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents AnalogInput3TextBox As System.Windows.Forms.TextBox
    Friend WithEvents AnalogInput2TextBox As System.Windows.Forms.TextBox
    Friend WithEvents AnalogInput1TextBox As System.Windows.Forms.TextBox
    Friend WithEvents AnalogInput3Label As System.Windows.Forms.Label
    Friend WithEvents AnalogInput2Label As System.Windows.Forms.Label
    Friend WithEvents AnalogInput1Label As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsSingle)> _
    Friend WithEvents AnalogInput3ScaleTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AnalogInput3ScaleLabel As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsSingle)> _
    Friend WithEvents AnalogInput2ScaleTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AnalogInput2ScaleLabel As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsSingle)> _
    Friend WithEvents AnalogInput1ScaleTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AnalogInput1ScaleLabel As System.Windows.Forms.Label
    Friend WithEvents AnalogInput3UnitTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AnalogInput2UnitTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AnalogInput1UnitTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SettingsToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents OutOfRangeWarningsGroupBox As System.Windows.Forms.GroupBox
    <Restriction(RestrictionAttribute.Restriction.IsSingle)> _
    Friend WithEvents AllowedRange3HighTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AnalogInput3WarningsHighLabel As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsSingle)> _
    Friend WithEvents AllowedRange2HighTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AnalogInput2WarningsHighLabel As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsSingle)> _
    Friend WithEvents AllowedRange1HighTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AnalogInput1WarningsHighLabel As System.Windows.Forms.Label
    Friend WithEvents AnalogInput3WarningsCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents AnalogInput2WarningsCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents AnalogInput1WarningsCheckBox As System.Windows.Forms.CheckBox
    <Restriction(RestrictionAttribute.Restriction.IsSingle)> _
    Friend WithEvents AllowedRange3LowTextBox As System.Windows.Forms.TextBox
    <Restriction(RestrictionAttribute.Restriction.IsSingle)> _
    Friend WithEvents AllowedRange2LowTextBox As System.Windows.Forms.TextBox
    <Restriction(RestrictionAttribute.Restriction.IsSingle)> _
    Friend WithEvents AllowedRange1LowTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AnalogInput3WarningsLowLabel As System.Windows.Forms.Label
    Friend WithEvents AnalogInput2WarningsLowLabel As System.Windows.Forms.Label
    Friend WithEvents AnalogInput1WarningsLowLabel As System.Windows.Forms.Label
    Friend WithEvents SettingsTabControl As System.Windows.Forms.TabControl
    Friend WithEvents CameraPanAndTiltTabPage As System.Windows.Forms.TabPage
    Friend WithEvents InputsOutputsTabPage As System.Windows.Forms.TabPage
    Friend WithEvents MotorTabPage As System.Windows.Forms.TabPage
    Friend WithEvents CommunicationTabPage As System.Windows.Forms.TabPage
    Friend WithEvents CameraConnectionGroupBox As System.Windows.Forms.GroupBox
    <Restriction(RestrictionAttribute.Restriction.IsInteger)> _
    Friend WithEvents reversePanPosition1TextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsIpAddress)> _
    Friend WithEvents CameraIPAddressTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CameraIPLabel As System.Windows.Forms.Label
    Friend WithEvents CameraPasswordTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CameraPasswordLabel As System.Windows.Forms.Label
    Friend WithEvents CameraLoginTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CameraLoginLabel As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger Or RestrictionAttribute.Restriction.IsInRange, 0, 65535)> _
    Friend WithEvents CameraPortTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CameraPortLabel As System.Windows.Forms.Label
    Friend WithEvents DriveControlSettingsGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents MotorReverseFastLabel As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger Or RestrictionAttribute.Restriction.IsInRange, 0, 255)> _
    Friend WithEvents MotorReverseFastTextBox As System.Windows.Forms.TextBox
    <Restriction(RestrictionAttribute.Restriction.IsInteger Or RestrictionAttribute.Restriction.IsInRange, 0, 255)> _
    Friend WithEvents MotorReverseSlowTextBox As System.Windows.Forms.TextBox
    <Restriction(RestrictionAttribute.Restriction.IsInteger Or RestrictionAttribute.Restriction.IsInRange, 0, 255)> _
    Friend WithEvents MotoroForwardFastTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MotorForwardFastLabel As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsInteger Or RestrictionAttribute.Restriction.IsInRange, 0, 255)> _
    Friend WithEvents MotorForwardSlowTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MotorReverseSlowLabel As System.Windows.Forms.Label
    Friend WithEvents MotorForwardSlowLabel As System.Windows.Forms.Label
    Friend WithEvents UseReverseBitCheckBox As System.Windows.Forms.CheckBox
    <Restriction(RestrictionAttribute.Restriction.IsInteger Or RestrictionAttribute.Restriction.IsInRange, 0, 255)> _
    Friend WithEvents MotorOffTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MotorOffLabel As System.Windows.Forms.Label
    Friend WithEvents CameraDeviceGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButtonRunAsClient As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonRunAsServer As System.Windows.Forms.RadioButton
    <Restriction(RestrictionAttribute.Restriction.IsInteger Or RestrictionAttribute.Restriction.IsInRange, 10, 60 * 60 * 1000)> _
    Friend WithEvents TextBoxMaximalNetLatency As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents LabelMaximalNetLatency As System.Windows.Forms.Label
    Friend WithEvents GroupBoxUltrasonicSensor As System.Windows.Forms.GroupBox
    <Restriction(RestrictionAttribute.Restriction.IsSingle)> _
    Friend WithEvents TextBoxOffset As System.Windows.Forms.TextBox
    Friend WithEvents LabelOffset As System.Windows.Forms.Label
    <Restriction(RestrictionAttribute.Restriction.IsSingle)> _
    Friend WithEvents TextBoxMultiplier As System.Windows.Forms.TextBox
    Friend WithEvents LabelUSSMultiplier As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBoxInvertTilt As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxInvertPan As System.Windows.Forms.CheckBox
    Friend WithEvents LabelEncoderUnits As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents LabelUltrasonicUnits As System.Windows.Forms.Label
    Friend WithEvents RadioButtonEncoderUnitMetric As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonEncoderUnitImperial As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonSensorUnitMetric As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonSensorUnitImperial As System.Windows.Forms.RadioButton
    <Restriction(RestrictionAttribute.Restriction.IsInteger Or RestrictionAttribute.Restriction.IsInRange, 10, 60 * 60 * 1000)> _
    Friend WithEvents TextBoxMaximalNetTimeout2 As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents cbEnableRemoteControllingAfterStartup As System.Windows.Forms.CheckBox
    Friend WithEvents CameraPresetTabPage As System.Windows.Forms.TabPage
    Friend WithEvents tbtPresetInfo As System.Windows.Forms.Label
    Friend WithEvents grbPreset1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents txtCameraPreset1Tilt As System.Windows.Forms.TextBox
    Friend WithEvents txtCameraPreset1Pan As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents grbPreset4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents txtCameraPreset4Tilt As System.Windows.Forms.TextBox
    Friend WithEvents txtCameraPreset4Pan As System.Windows.Forms.TextBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents grbPreset3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents txtCameraPreset3Tilt As System.Windows.Forms.TextBox
    Friend WithEvents txtCameraPreset3Pan As System.Windows.Forms.TextBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents grbPreset2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents txtCameraPreset2Tilt As System.Windows.Forms.TextBox
    Friend WithEvents txtCameraPreset2Pan As System.Windows.Forms.TextBox
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents FunctionsTabPage As System.Windows.Forms.TabPage
    Friend WithEvents chbDisableEncoders As System.Windows.Forms.CheckBox
    Friend WithEvents chbDisableSonar As System.Windows.Forms.CheckBox
    Friend WithEvents chbDisablePanTilt As System.Windows.Forms.CheckBox
    Friend WithEvents chbDisableBumperSwitch As System.Windows.Forms.CheckBox
    Friend WithEvents chbDisableMotorMixing As System.Windows.Forms.CheckBox
    Friend WithEvents chbEnableTiltTimerReset As System.Windows.Forms.CheckBox
    Friend WithEvents chbEnablePanTimerReset As System.Windows.Forms.CheckBox
    Friend WithEvents ComunicationCametaTabPage As System.Windows.Forms.TabPage
    Friend WithEvents UsbCameraConnectionGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents cmbVideoPreviewSize As System.Windows.Forms.ComboBox
    Friend WithEvents lblVideoPreviewSize As System.Windows.Forms.Label
    Friend WithEvents UsbCamVideoDeviceComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents UsbCamVideoDeviceLabel As System.Windows.Forms.Label
    Friend WithEvents UsbCameraEncodingGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents cmbVideoEncodingResolution As System.Windows.Forms.ComboBox
    Friend WithEvents lblVideoEncodingResolution As System.Windows.Forms.Label
    Private WithEvents lblVideoBitRate As System.Windows.Forms.Label
    Private WithEvents lblIFrameFrequency As System.Windows.Forms.Label
    Friend WithEvents txtVideoIFrameFrequency As System.Windows.Forms.TextBox
    Friend WithEvents txtVideoBitRate As System.Windows.Forms.TextBox
    Private WithEvents lblVideoFrameCaptureInterval As System.Windows.Forms.Label
    Friend WithEvents txtVideoFrameCaptureInterval As System.Windows.Forms.TextBox
    Private WithEvents lblVideoFrameRate As System.Windows.Forms.Label
    Friend WithEvents txtVideoFrameRate As System.Windows.Forms.TextBox
    Friend WithEvents lblVideoH264Profile As System.Windows.Forms.Label
    Friend WithEvents lblVideoH264SpeedLevel As System.Windows.Forms.Label
    Friend WithEvents cmbVideoH264Profile As System.Windows.Forms.ComboBox
    Friend WithEvents cmbVideoH264SpeedLevel As System.Windows.Forms.ComboBox
    Friend WithEvents lblCodecInfo As System.Windows.Forms.Label
    Friend WithEvents AudioGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents cmbAudioOutput As System.Windows.Forms.ComboBox
    Friend WithEvents lblAudioOutput As System.Windows.Forms.Label
    Friend WithEvents cmbAudioInput As System.Windows.Forms.ComboBox
    Friend WithEvents lblAudioInput As System.Windows.Forms.Label
    Friend WithEvents chbDisableZoom As System.Windows.Forms.CheckBox
    Friend WithEvents chbDisableEncodersCount As System.Windows.Forms.CheckBox
End Class
