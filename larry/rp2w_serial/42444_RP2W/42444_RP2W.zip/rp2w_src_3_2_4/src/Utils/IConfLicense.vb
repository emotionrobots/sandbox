﻿Public Module IConfLicense
    Public ReadOnly Property LicenseKey() As String
        Get
            Return "eGF2c3BlZWR4ZGVvZGVpdWgzanN1cGRybzAwMzY3NDY3NQ=="
        End Get
    End Property
End Module
